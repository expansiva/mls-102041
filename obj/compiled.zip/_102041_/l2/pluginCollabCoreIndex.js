/// <mls fileReference="_102041_/l2/pluginCollabCoreIndex.ts" enhancement="_blank"/>
import { PluginBaseIndex } from '/_102027_/l2/pluginBaseIndex.js';
export class PluginCollabCoreIndex extends PluginBaseIndex {
    getMenus() {
        return [];
    }
    getHooks() {
        return [];
    }
    getServices() {
        return [];
    }
}
export default new PluginCollabCoreIndex();
