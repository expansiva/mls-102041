/// <mls fileReference="_102041_/l2/servicePublish.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
let ServicePublish102041 = class ServicePublish102041 extends ServiceBase {
    constructor() {
        super(...arguments);
        this.details = {
            icon: '&#xf15b',
            state: 'foreground',
            position: 'right',
            tooltip: 'Service Example',
            visible: true,
            widget: '_102041_servicePublish',
            level: [5]
        };
        this.menu = {
            title: 'Example',
            main: {},
            tools: {},
            tabs: undefined,
            onClickMain: this.onClickMain.bind(this),
        };
        this.name = 'Somebody';
    }
    onClickMain(op) {
        if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onServiceClick(visible, reinit, el) {
    }
    render() {
        return html `<p> Hello, ${this.name} !</p>`;
    }
};
__decorate([
    property()
], ServicePublish102041.prototype, "name", void 0);
ServicePublish102041 = __decorate([
    customElement('service-publish-102041')
], ServicePublish102041);
export { ServicePublish102041 };
