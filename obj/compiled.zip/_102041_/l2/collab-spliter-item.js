/// <mls fileReference="_102041_/l2/collab-spliter-item.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { nothing } from 'lit';
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
export class CollabSpliterItem extends StateLitElement {
    constructor() {
        super(...arguments);
        this.msize = '';
    }
    layout() {
        const nav3 = this.querySelector('collab-nav-3');
        const nav2 = this.querySelector('collab-nav-2');
        if (nav3)
            nav3.layout();
        if (nav2)
            nav2.layout();
    }
    render() { return nothing; }
    updated(changed) {
        if (changed.has('msize'))
            this._setMSizeNav3(this.msize);
    }
    _setMSizeNav3(msize) {
        if (!msize)
            return;
        const nav2 = this.querySelector('collab-nav-2');
        const nav3 = this.querySelector('collab-nav-3');
        if (!nav3 || !nav2)
            return;
        const heightNav2 = +(nav2.getAttribute('mheight') || '0');
        const [width, height, top, left] = msize.split(',');
        const newHeight = (+height) - heightNav2;
        const newTop = (+top) + heightNav2;
        nav3.setAttribute('msize', [width, newHeight.toFixed(2), newTop.toFixed(2), left].join(','));
    }
}
__decorate([
    property({ attribute: 'msize' })
], CollabSpliterItem.prototype, "msize", void 0);
window.addEventListener('mls:ready', () => customElements.define('collab-spliter-item', CollabSpliterItem), { once: true });
