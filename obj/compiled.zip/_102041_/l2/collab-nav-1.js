/// <mls fileReference="_102041_/l2/collab-nav-1.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_en = {
    l7Collab: 'L7 - Collab',
    l6Site: 'L6 - Site',
    l5Project: 'L5 - Project',
    l4Business: 'L4 - Business',
    l3Design: 'L3 - Design',
    l2Components: 'L2 - Components',
    l1Backend: 'L1 - Back-End',
    user: 'User',
};
const message_pt = {
    l7Collab: 'L7 - Collab',
    l6Site: 'L6 - Site',
    l5Project: 'L5 - Projeto',
    l4Business: 'L4 - Negócios',
    l3Design: 'L3 - Design',
    l2Components: 'L2 - Componentes',
    l1Backend: 'L1 - Back-End',
    user: 'Usuário',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
import { html, nothing } from 'lit';
import { property, state } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { SERVICE_START_WIDGET, levelHasStartService } from '/_102041_/l2/utils.js';
import { getPath, convertFileNameToTag } from '/_102027_/l2/utils.js';
export class CollabNav1 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-nav-1 {
  position: relative;
  display: block;
  height: 30px;
}
collab-nav-1 nav {
  background-color: var(--collab-nav-bg-1);
  display: flex !important;
  height: 30px;
}
collab-nav-1 nav .nav-1-user {
  position: relative;
  margin-left: auto;
}
collab-nav-1 nav nav-1-notification {
  position: relative;
  margin-left: auto;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  font-style: normal;
  cursor: pointer;
  margin-right: 1rem;
}
collab-nav-1 nav nav-1-notification.enabled {
  pointer-events: all;
  cursor: pointer;
}
collab-nav-1 nav nav-1-notification.disabled {
  cursor: not-allowed;
  color: #cecece;
  pointer-events: none;
}
collab-nav-1 nav nav-1-notification:before {
  content: attr(data-count);
  position: absolute;
  top: 0px;
  right: -8px;
  background-color: red;
  color: white;
  border-radius: 50%;
  width: 6px;
  height: 6px;
  padding: 5px;
  font-size: 7px;
  text-align: center;
  display: none;
}
collab-nav-1 nav nav-1-notification[data-count="0"]:before {
  display: none;
}
collab-nav-1 nav nav-1-notification[data-count]:not([data-count="0"]):before {
  display: flex;
  align-items: center;
}
collab-nav-1 nav nav-1-item {
  user-select: none;
  padding: 0rem 0.8rem;
  color: var(--collab-nav-color);
  background-color: var(--collab-nav-bg-1);
  border-top-left-radius: 0.25rem;
  border-top-right-radius: 0.25rem;
  text-decoration: none;
  cursor: pointer;
  line-height: 1;
  font-family: FontAwesome;
  font-size: 12px;
  text-rendering: auto;
  -webkit-font-smoothing: antialiased;
  display: flex;
  align-items: center;
}
collab-nav-1 nav nav-1-item.enabled {
  pointer-events: all;
  cursor: pointer;
}
collab-nav-1 nav nav-1-item.disabled {
  cursor: not-allowed;
  color: #cecece;
  pointer-events: none;
}
collab-nav-1 nav nav-1-item.active {
  color: var(--collab-nav-color-active) !important;
  background: linear-gradient(360deg, var(--collab-nav-bg-2) 0%, var(--collab-nav-bg-1) 100%);
}
collab-nav-1 nav nav-1-item:hover {
  background: linear-gradient(360deg, var(--collab-nav-bg-2) 0%, var(--collab-nav-bg-1) 100%);
  text-decoration: none;
}
collab-nav-1 nav nav-1-item .additional-container {
  display: flex;
  align-items: center;
}
collab-nav-1 nav nav-1-item .additional-text {
  margin-right: 1rem;
  font-family: 'Cambria', serif;
  font-size: 12px;
  text-transform: uppercase;
}
collab-nav-1 nav nav-1-item .additional-img {
  margin-right: 0.2rem;
  width: 20px;
}
collab-nav-1 nav nav-1-item .avatar {
  width: 25px;
  height: 25px;
  background-size: cover;
  background-position: top center;
  border-radius: 50%;
}
`);
        this.tabindexactive = '';
        this.status = '';
        this.msg = messages['en'];
        this._currentLang = 'en';
        this.services = { services: [] };
        this.reasons = {};
        this._items = this._defaultJson();
        this._statusMap = {};
        this._activeIndex = -1;
        this._notificationCount = 0;
        this._userAvatarSrc = '';
        this._lastActive = -1;
        this._levelAlreadyReady = { 0: false, 1: false, 2: false, 3: false, 4: false, 5: false, 6: false, 7: false };
        this._servicesDetailsArr = {};
        this._cacheInstancePromise = null;
        this._cacheKeysPromise = null;
        this._staticService = [SERVICE_START_WIDGET];
    }
    get tabActive() { return this.tabindexactive ? +this.tabindexactive : -1; }
    get actualLevel() { return [7, 6, 5, 4, 3, 2, 1, 0][this.tabActive > -1 ? this.tabActive : 0]; }
    get project() { return +(this.getAttribute('initialproject') || '0'); }
    openService(service, position, level, args) {
        return this._openService(service, position, level, args);
    }
    addNotification(clear) { this._setNotificationCount(clear); }
    changeIconToImage(tabIndex, src, additional) {
        this._userAvatarSrc = src;
        this._userAdditional = additional;
    }
    async forceInstanceIfNeed(arr) {
        const page = this.closest('collab-page');
        if (!page)
            return;
        const navs3 = Array.from(page.querySelectorAll('collab-nav-3'));
        for (const nav3 of navs3)
            await nav3['instanceServicesIfNeed'](arr);
    }
    updated(changed) {
        if (changed.has('tabindexactive')) {
            const oldVal = changed.get('tabindexactive');
            if (oldVal === '5' && window.mls && mls?.stor?.cache?.['clearObsoleteCache']) {
                mls.stor.cache['clearObsoleteCache']();
            }
            if (this._lastActive !== this.tabActive && this.status !== 'start')
                this._activeMe(this.tabActive);
        }
        if (changed.has('status'))
            this._changeStatus();
        this._registerTooltips();
    }
    render() {
        const lang = this.getMessageKey(messages);
        if (lang !== this._currentLang) {
            this._currentLang = lang;
            this.msg = messages[lang] || messages['en'];
            this._items = this._defaultJson();
        }
        return html `
            <nav class="fa">
                ${this._items.map((item, idx) => {
            const tabI = this._items.slice(0, idx).filter(i => i.mode !== 'notification').length;
            if (item.mode === 'notification')
                return this._renderNotification(item);
            if (item.mode === 'user')
                return this._renderUser(item, tabI);
            return this._renderTab(item, tabI);
        })}
            </nav>
        `;
    }
    _renderTab(item, tabI) {
        const notifOffset = this._items.filter(i => i.mode === 'notification').length;
        const realTabI = tabI - notifOffset >= 0 ? tabI - notifOffset : tabI;
        const shortcut = this._getShortcut(realTabI, this._items.filter(i => i.mode === 'tab').length - 1);
        const statusCls = this._statusMap[realTabI] || '';
        return html `
            <nav-1-item
                level="${item.text}"
                data-tooltip="${item.tooltip} (${shortcut})"
                class=${classMap({ active: this._activeIndex === realTabI, [statusCls]: !!statusCls })}
                @click=${() => this._activeMe(realTabI)}>
                ${unsafeHTML(item.icon)} ${item.text}
            </nav-1-item>
        `;
    }
    _renderNotification(item) {
        const shortcut = this._getShortcutLetter('N');
        return html `
            <nav-1-notification
                data-count="${this._notificationCount || nothing}"
                data-tooltip="${item.tooltip} (${shortcut})"
                style="margin-left: auto"
                @click=${() => this.openService('_100554_serviceUser', 'left', 0, { plugin: '_100554_pluginSystemNotification' })}>
                ${unsafeHTML(item.icon)} ${item.text}
            </nav-1-notification>
        `;
    }
    _renderUser(item, tabI) {
        const shortcut = this._getShortcut(tabI, this._items.length - 1);
        return html `
            <nav-1-item
                level="${item.text}"
                data-tooltip="${item.tooltip} (${shortcut})"
                class="nav-1-user"
                style="font-size:18px; margin-left: auto"
                @click=${(e) => this._onUserClick(e, tabI)}>
                ${this._userAdditional ? html `
                    <div class="additional-container">
                        ${this._userAdditional.img ? html `<img class="additional-img" src="${this._userAdditional.img}" alt="${this._userAdditional.text}">` : nothing}
                        <span class="additional-text">${this._userAdditional.text}</span>
                    </div>
                ` : nothing}
                ${this._userAvatarSrc
            ? html `<img class="avatar" src="${this._userAvatarSrc}" alt="user avatar">`
            : html `${unsafeHTML(item.icon)} ${item.text}`}
            </nav-1-item>
        `;
    }
    _registerTooltips() {
        const register = () => {
            const tooltip = document.querySelector('collab-tooltip');
            if (!tooltip?.tooltip)
                return;
            this.querySelectorAll('nav-1-item, nav-1-notification').forEach(el => tooltip.tooltip(el));
        };
        // se o collab-tooltip ainda não foi upgraded no 1º load, re-tenta após a definição;
        // re-registrar é idempotente (addEventListener deduplica listeners estáveis).
        if (customElements.get('collab-tooltip'))
            register();
        else
            customElements.whenDefined('collab-tooltip').then(register);
    }
    _onUserClick(e, tabI) {
        const target = e.target;
        if (target.closest('.additional-container')) {
            this.openService('_100554_serviceUser', 'left', 0, { plugin: '_100554_pluginSystemLanguage' });
            return;
        }
        if (target.closest('.avatar')) {
            this.openService('_100554_serviceUser', 'left', 0, { plugin: '_100554_pluginSystemUser' });
            return;
        }
        this._activeMe(tabI);
    }
    _setNotificationCount(clear) {
        let count = this._notificationCount;
        if (clear)
            count = 0;
        else
            count = count >= 9 ? 9 : count + 1;
        this._notificationCount = count;
    }
    _openService(service, position, level, args) {
        const page = this.closest('collab-page');
        if (!page)
            return;
        const toolbar = page.querySelector(`collab-nav-2[toolbarposition="${position}"]`);
        const nav3 = page.querySelector(`collab-nav-3[toolbarposition="${position}"]`);
        if (!toolbar)
            return;
        if (args && nav3)
            nav3.args = args;
        if (this.actualLevel !== level) {
            if (toolbar.state_)
                toolbar.state_[level][position] = service;
            this._selectLevel(level);
            return;
        }
        const item = toolbar.querySelector(`collab-nav-2-item[data-service="${service}"]`);
        if (item)
            item.click();
    }
    _selectLevel(level) {
        const page = this.closest('collab-page');
        const nav = page?.querySelector('collab-nav-1');
        const objIndex = { 0: 7, 1: 6, 2: 5, 3: 4, 4: 3, 5: 2, 6: 1, 7: 0 };
        if (!nav)
            return;
        nav.setAttribute('tabindexactive', String(objIndex[level]));
    }
    _activeMe(idx) {
        const tabItems = this._items.filter(i => i.mode !== 'notification');
        let lastLevel = -1;
        const act = this.querySelector('nav-1-item.active');
        if (act) {
            const lvl = act.getAttribute('level');
            if (lvl)
                lastLevel = +lvl;
        }
        const tabI = this._items.filter(i => i.mode !== 'notification').length - 1;
        if (idx < 0 || idx > tabI)
            return;
        this._activeIndex = idx;
        this._lastActive = idx;
        this.setAttribute('tabindexactive', String(idx));
        if (window.mls && mls?.setActualLevel)
            mls.setActualLevel(this.actualLevel);
        this._fireChangeLevel(lastLevel);
    }
    async _fireChangeLevel(lastLevel) {
        await Promise.all(['collab-nav-2', 'collab-nav-3'].map(wc => customElements.whenDefined(wc)));
        const collabPage = this.closest('collab-page');
        if (!collabPage)
            return;
        const nav2s = Array.from(collabPage.querySelectorAll('collab-nav-2'));
        if (nav2s.length < 2)
            return;
        const [nav2Right, nav2Left] = nav2s;
        const collabSpliter = collabPage.querySelector('collab-spliter');
        collabPage.querySelectorAll('collab-nav-3').forEach(nav3 => nav3.setAttribute('level', String(this.actualLevel)));
        nav2Right.setAttribute('status', 'start');
        nav2Left.setAttribute('status', 'start');
        nav2Right.setAttribute('level', String(this.actualLevel));
        nav2Left.setAttribute('level', String(this.actualLevel));
        const levelCollab = `l${this.actualLevel}`;
        mls[levelCollab].init('enterLevel');
        const params = { from: lastLevel, to: this.actualLevel };
        if (this._levelAlreadyReady[this.actualLevel]) {
            await this._prepareServices();
            mls?.events?.fire([this.actualLevel], ['LevelChanged'], JSON.stringify(params));
        }
        else {
            await this._checkIsAllLoaded(this.actualLevel);
            this._levelAlreadyReady[this.actualLevel] = true;
            await this._prepareServices();
            mls?.events?.fire([this.actualLevel], ['LevelChanged'], JSON.stringify(params));
        }
        nav2Right.setAttribute('status', 'enabled');
        nav2Left.setAttribute('status', 'enabled');
        collabSpliter?.setAttribute('level', String(this.actualLevel));
    }
    async _changeStatus() {
        if (this.status === 'start') {
            await Promise.all(['collab-nav-2', 'collab-nav-3'].map(wc => customElements.whenDefined(wc)));
            const page = this.closest('collab-page');
            if (!page)
                return;
            this._activeIndex = 0;
            this._lastActive = 0;
            const startLevel = String(this.actualLevel);
            const nav2sStatus = Array.from(page.querySelectorAll('collab-nav-2'));
            const [nav2Right, nav2Left] = nav2sStatus;
            page.querySelectorAll('collab-nav-3').forEach(n3 => n3.setAttribute('level', startLevel));
            nav2Right?.setAttribute('level', startLevel);
            nav2Left?.setAttribute('level', startLevel);
            nav2Right?.setAttribute('status', 'start');
            nav2Left?.setAttribute('status', 'start');
        }
        if (this.status === 'anonymous') {
            await this._changeStatusIfAnonymous();
            return;
        }
        if (this.status === 'enabled' && this.tabActive >= 0)
            this._activeMe(this.tabActive);
        const tabItems = this._items.filter(i => i.mode !== 'notification');
        const newMap = {};
        tabItems.forEach((_, idx) => {
            const isActive = idx === this._activeIndex;
            if (isActive)
                return;
            if (this.status === 'start' && idx === 0)
                newMap[idx] = 'enabled';
            else if (this.status === 'start')
                newMap[idx] = 'disabled';
            else
                newMap[idx] = this.status;
        });
        this._statusMap = newMap;
    }
    async _changeStatusIfAnonymous() {
        await mls?.stor?.server?.loadProjectInfoIfNeeded(this.project);
        this._activeMe(this.tabActive);
        const tabLevel7El = this.querySelector('nav-1-item[level="7"]');
        if (tabLevel7El && !tabLevel7El.classList.contains('active')) {
            tabLevel7El.className = 'enabled';
        }
    }
    async _checkIsAllLoaded(level) {
        const levelCollab = `l${level}`;
        ;
        mls[levelCollab].init('preLoading');
    }
    async _prepareServices() {
        this.actualServices = await this._getUserServicesPreferences();
    }
    async _getUserServicesPreferences() {
        const rc = this._prepareServicesByConfigProject(this.services, []);
        return this._mergeData(rc, this.actualLevel);
    }
    async _mergeData(data, actualLevel) {
        const servicesDetails = [];
        const servicesPromises = [];
        for (const [level, services] of Object.entries(data)) {
            for (const position of Object.keys(services)) {
                for (const service of services[position]) {
                    mls?.actual?.[0]?.setFullName(service.widget);
                    const { path, project } = mls?.actual?.[0] || {};
                    if (project && path) {
                        const driver = mls?.l5?.getProjectSettings?.(project)?.projectDriver;
                        if (!this._servicesDetailsArr[service.widget]) {
                            if (this._staticService.includes(service.widget)) {
                                const _det = await this._getDetailsServiceStatic(service.widget);
                                if (_det) {
                                    servicesDetails.push({ details: _det });
                                }
                            }
                            else {
                                servicesPromises.push(this._getDetailsServiceCollabInJS3(level, position, project, path));
                            }
                            this._servicesDetailsArr[service.widget] = {};
                        }
                    }
                }
            }
        }
        const results = await Promise.allSettled(servicesPromises);
        results.forEach((r) => {
            if (r.status === 'fulfilled')
                servicesDetails.push(r.value);
            else
                console.error(r.reason);
        });
        for (const d of servicesDetails) {
            if (!d?.details)
                continue;
            this._servicesDetailsArr[d.details.widget] = d.details;
        }
        return this._mergeData2(data, actualLevel);
    }
    _mergeData2(data, actualLevel) {
        Object.entries(data).forEach(([level, services]) => {
            Object.keys(services).forEach(position => {
                services[position].forEach((service) => {
                    const d = this._servicesDetailsArr[service.widget];
                    if (!d || Object.keys(d).length === 0)
                        return;
                    service.icon = d.icon;
                    service.visible = d.visible;
                    service.tooltip = d.tooltip;
                    service.state = d.state;
                    if (d.tags)
                        service.tags = d.tags;
                    if (d.customConfiguration?.[(+level)]) {
                        const cfg = d.customConfiguration[+level];
                        const typeConfig = ('left' in cfg || 'right' in cfg) ? 'byPosition' : 'byPlace';
                        const obj = typeConfig === 'byPlace' ? cfg : cfg[position];
                        if (obj?.show === false)
                            return;
                        if (obj)
                            Object.keys(obj).forEach(key => { service = obj[key]; });
                    }
                });
            });
        });
        return data;
    }
    async _getDetailsServiceStatic(widget) {
        // Folder-aware tag derivation (shared with collab-nav-3 / 102027 utils).
        const info = getPath(widget);
        const tag = convertFileNameToTag(info ?? { shortName: widget, project: 0 });
        const _temp = document.createElement(tag);
        if (!_temp)
            return;
        if (!_temp.details)
            return;
        return _temp.details;
    }
    async _getCacheInstance() {
        if (!this._cacheInstancePromise)
            this._cacheInstancePromise = caches.open('mls-v2');
        return this._cacheInstancePromise;
    }
    async _getCacheKeys() {
        if (!this._cacheKeysPromise) {
            this._cacheKeysPromise = (async () => { const c = await this._getCacheInstance(); return c.keys(); })();
        }
        return this._cacheKeysPromise;
    }
    async _getDetailsServiceCollabInJS3(level, position, project, path) {
        const target = `/_${project}_${path}.js`;
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 8000);
        let response;
        try {
            response = await fetch(target, { signal: controller.signal });
        }
        catch (err) {
            clearTimeout(timeout);
            if (err?.name === 'AbortError')
                throw new Error(`Request timeout while fetching ${target}`);
            throw new Error(`Network error while fetching ${target}: ${err}`);
        }
        clearTimeout(timeout);
        if (!response.ok)
            throw new Error(`Failed to fetch ${target}: HTTP ${response.status}`);
        const jsCode = await response.text();
        if (jsCode.trim().startsWith('<'))
            throw new Error(`Unexpected HTML content from ${target}`);
        const details = await this._getDetailsService2(jsCode);
        return { details };
    }
    async _getDetailsService2(content) {
        if (typeof content !== 'string')
            return undefined;
        const markers = ['this.details =', 'details ='];
        let startMarker, startIndex = -1;
        for (const m of markers) {
            const i = content.indexOf(m);
            if (i !== -1 && (startIndex === -1 || i < startIndex)) {
                startIndex = i;
                startMarker = m;
            }
        }
        if (!startMarker || startIndex === -1)
            return undefined;
        let open = 0, close = 0, endIndex = -1;
        for (let i = startIndex; i < content.length; i++) {
            if (content[i] === '{')
                open++;
            if (content[i] === '}')
                close++;
            if (open !== 0 && open === close) {
                endIndex = i;
                break;
            }
        }
        if (endIndex === -1)
            return undefined;
        let block = content.substring(startIndex + startMarker.length, endIndex + 1).trim();
        block = block.substring(block.indexOf('{')).trim();
        let result;
        try {
            eval('result = ' + block);
        }
        catch {
            return undefined;
        }
        return result;
    }
    _prepareServicesByConfigProject(servicesByConfig, userPreferences) {
        const staticStart = { icon: '', isStatic: false, state: 'foreground', tooltip: '', visible: true, widget: SERVICE_START_WIDGET };
        const _cfg = servicesByConfig || { services: [] };
        const parsedConfig = this._parseJsonServicesByConfig(_cfg);
        const parsedPrefs = this._prepareJSONServiceData(userPreferences);
        Object.entries(parsedConfig).forEach(([key, value]) => {
            const _key = Number.parseInt(key);
            // No start service inside a client app (levelHasStartService).
            const start = levelHasStartService(_key) ? [staticStart] : [];
            if (value.left.length === 1 && value.left[0] === '*')
                parsedPrefs[_key].left = start;
            else if (value.left.length > 0) {
                parsedPrefs[_key].left = [...start, ...value.left.map((w) => ({ icon: '', isStatic: false, state: 'foreground', tooltip: '', visible: true, widget: w }))];
            }
            if (value.right.length === 1 && value.right[0] === '*')
                parsedPrefs[_key].right = [];
            else if (value.right.length > 0) {
                parsedPrefs[_key].right = value.right.map((w) => ({ icon: '', isStatic: false, state: 'foreground', tooltip: '', visible: true, widget: w }));
            }
        });
        return parsedPrefs;
    }
    _prepareJSONServiceData(services) {
        const obj = { 0: { left: [], right: [] }, 1: { left: [], right: [] }, 2: { left: [], right: [] }, 3: { left: [], right: [] }, 4: { left: [], right: [] }, 5: { left: [], right: [] }, 6: { left: [], right: [] }, 7: { left: [], right: [] } };
        if (!services || services.length === 0)
            return obj;
        services.forEach(s => {
            s.places.forEach((p) => {
                const d = { icon: '', state: p.state, tooltip: '', visible: true, widget: s.widget, isStatic: false };
                while (obj[p.level][p.position].length <= p.index)
                    obj[p.level][p.position].push(undefined);
                obj[p.level][p.position][p.index] = d;
            });
        });
        Object.keys(obj).forEach(l => { Object.keys(obj[l]).forEach(p => { obj[l][p] = obj[l][p].filter((i) => i !== undefined); }); });
        return obj;
    }
    _parseJsonServicesByConfig(json) {
        const rc = {};
        if (!json?.services)
            return rc;
        json.services.forEach((item, index) => {
            rc[index] = { left: [], right: [] };
            if (typeof item === 'string' && item.startsWith('-*')) {
                rc[index].right = ['*'];
                rc[index].left = ['*'];
                return;
            }
            if (!item)
                return;
            const [left, right] = item.split(';');
            if (left)
                rc[index].left = left.split(',');
            if (right)
                rc[index].right = right.split(',');
        });
        return rc;
    }
    _getShortcut(index, totalItems) {
        const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
        const i = totalItems - index - 1;
        return isMac ? `⌥+${i}` : `Alt+${i}`;
    }
    _getShortcutLetter(letter) {
        const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
        return isMac ? `⌥+${letter}` : `Alt+${letter}`;
    }
    _defaultJson() {
        return [
            { level: 7, text: '7', icon: '&#xf015', tooltip: this.msg.l7Collab, mode: 'tab' },
            { level: 6, text: '6', icon: '&#xf007', tooltip: this.msg.l6Site, mode: 'tab' },
            { level: 5, text: '5', icon: '&#xf013', tooltip: this.msg.l5Project, mode: 'tab' },
            { level: 4, text: '4', icon: '&#xf0e8', tooltip: this.msg.l4Business, mode: 'tab' },
            { level: 3, text: '3', icon: '&#xf5ae', tooltip: this.msg.l3Design, mode: 'tab' },
            { level: 2, text: '2', icon: '&#xf1b3', tooltip: this.msg.l2Components, mode: 'tab' },
            { level: 1, text: '1', icon: '&#xf233', tooltip: this.msg.l1Backend, mode: 'tab' },
            { level: 0, text: '', icon: '&#xf2bd', tooltip: this.msg.user, mode: 'user', align: 'right' },
        ];
    }
}
__decorate([
    property({ attribute: 'tabindexactive' })
], CollabNav1.prototype, "tabindexactive", void 0);
__decorate([
    property({ attribute: 'status' })
], CollabNav1.prototype, "status", void 0);
__decorate([
    state()
], CollabNav1.prototype, "_items", void 0);
__decorate([
    state()
], CollabNav1.prototype, "_statusMap", void 0);
__decorate([
    state()
], CollabNav1.prototype, "_activeIndex", void 0);
__decorate([
    state()
], CollabNav1.prototype, "_notificationCount", void 0);
__decorate([
    state()
], CollabNav1.prototype, "_userAvatarSrc", void 0);
__decorate([
    state()
], CollabNav1.prototype, "_userAdditional", void 0);
window.addEventListener('mls:ready', () => customElements.define('collab-nav-1', CollabNav1), { once: true });
