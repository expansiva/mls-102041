/// <mls fileReference="_102041_/l2/collab-start-l7.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
import { COLLAB_LOGIN_PLUGIN, EXPLORE_PROJECTS_SERVICE } from '/_102041_/l2/utils.js';
import '/_102041_/l2/collab-ticker.js';
let CollabStartL7 = class CollabStartL7 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.language = '';
        this.mode = '';
        this.msize = '';
        this._iframeVisible = false;
    }
    get baseUrl() { return this.getAttribute('base'); }
    get _msizeObj() {
        const rc = { width: 0, height: 0, top: 0, left: 0 };
        if (this.msize) {
            const [width, height, top, left] = this.msize.split(',');
            if (!width || !height || !top || !left)
                return rc;
            rc.height = Number.parseFloat(height);
            rc.width = Number.parseFloat(width);
            rc.top = Number.parseFloat(top);
            rc.left = Number.parseFloat(left);
        }
        return rc;
    }
    render() {
        return html `
            ${!this._iframeVisible ? html `
                <div id="placeholder" class="collab-codes-start">
                    <div>
                        <div class="section1">
                            <div class="slogan">
                                <div class="opt2">
                                    <div class="l7-icon-div">
                                        <img id="l7_icon"
                                            src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjYwIiBoZWlnaHQ9IjYwIiBmaWxsPSJ0cmFuc3BhcmVudCIgLz4KICA8dGV4dCB4PSIzMCIgeT0iNTYiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjcyIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iIzQyODVGNCI+QzwvdGV4dD4KICA8dGV4dCB4PSI0MCIgeT0iNDAiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjM4IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iI0VBNDMzNSI+YzwvdGV4dD4KPC9zdmc+Cg=="
                                            height="120" width="120" alt="Ícone Collab Codes">
                                    </div>
                                    <div class="ticker-content"">
                                        <h1>ollab.</h1>
                                        <collab-ticker text="<i>codes</i>" element="h1"></collab-ticker>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            ` : nothing}
            <div id="iframe-container" style="display:${this._iframeVisible ? 'block' : 'none'}"></div>
        `;
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        this._setEvents();
    }
    updated(changed) {
        super.updated(changed);
        if (changed.has('mode') && changed.get('mode') !== undefined && this.mode !== '') {
            this._loadIframe();
        }
        if (changed.has('msize')) {
            const iframe = this.querySelector('#iframe-container iframe');
            if (iframe)
                iframe.style.height = this._msizeObj.height + 'px';
        }
    }
    async _loadIframe() {
        const params = new URLSearchParams(window.location.search);
        const spliter = document.querySelector('collab-spliter');
        if (this.mode === 'default' && params.has('signin')) {
            if (spliter)
                spliter.setFullScreen(7, 'left');
        }
        else if (this.mode === 'anonymous') {
            this._setDetailsInitialPlugin(COLLAB_LOGIN_PLUGIN);
            if (spliter)
                spliter.setFullScreen(7, 'right');
        }
        const iframeContainer = this.querySelector('#iframe-container');
        if (!iframeContainer)
            return;
        iframeContainer.innerHTML = '';
        const iframe = document.createElement('iframe');
        iframe.style.border = 'none';
        iframe.style.width = '100%';
        iframe.style.height = this._msizeObj.height + 'px';
        iframe.src = this.baseUrl ? `${this.baseUrl}/landingpage.html` : `https://www.collab.codes/landingpage.html`;
        iframe.onload = () => this._onIframeLoaded();
        iframe.onerror = () => this._onIframeLoaded();
        iframeContainer.appendChild(iframe);
    }
    _onIframeLoaded() {
        this._iframeVisible = true;
        const iframeContainer = this.querySelector('#iframe-container');
        if (iframeContainer)
            iframeContainer.classList.add('show');
    }
    _setEvents() {
        window.addEventListener('message', (event) => {
            const { action, type } = event.data;
            if (type !== 'iframeL7')
                return;
            if (action === 'login') {
                const spliter = document.querySelector('collab-spliter');
                if (this.mode === 'anonymous') {
                    this._setDetailsInitialPlugin(COLLAB_LOGIN_PLUGIN);
                    if (spliter)
                        spliter.setFullScreen(7, 'right');
                }
                else {
                    const options = { shortName: 'pluginCollabLogin', project: 100554, htmlText: '' };
                    mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify(options), 0);
                    if (spliter)
                        spliter.setFullScreen(7, 'default');
                }
            }
            if (action === 'create-project') {
                const nav1 = document.querySelector('collab-page')?.querySelector('collab-nav-1');
                if (nav1)
                    nav1.openService(EXPLORE_PROJECTS_SERVICE, 'left', 6, { currentScenario: 'add' });
            }
            if (action === 'explore-projects') {
                const nav1 = document.querySelector('collab-page')?.querySelector('collab-nav-1');
                if (nav1)
                    nav1.openService(EXPLORE_PROJECTS_SERVICE, 'left', 6, { currentScenario: 'list' });
            }
        });
    }
    _loadScript(src) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = src;
            script.type = 'module';
            script.onload = () => resolve();
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }
    async _setDetailsInitialPlugin(plugin) {
        await this._loadScript('/_100554_/l2/pluginCollabLogin.js');
        await Promise.all([
            customElements.whenDefined('collab-nav-2'),
            customElements.whenDefined('collab-nav-3'),
            customElements.whenDefined('plugin-collab-login-100554'),
        ]);
        const page = document.querySelector('collab-page');
        const nav3 = page?.querySelector('collab-nav-3[toolbarposition="right"]');
        const pluginLogin = document.createElement('plugin-collab-login-100554');
        nav3.appendChild(pluginLogin);
    }
};
__decorate([
    property({ attribute: 'language' })
], CollabStartL7.prototype, "language", void 0);
__decorate([
    property({ attribute: 'mode' })
], CollabStartL7.prototype, "mode", void 0);
__decorate([
    property({ attribute: 'msize' })
], CollabStartL7.prototype, "msize", void 0);
__decorate([
    state()
], CollabStartL7.prototype, "_iframeVisible", void 0);
CollabStartL7 = __decorate([
    customElement('collab-start-l7')
], CollabStartL7);
export { CollabStartL7 };
