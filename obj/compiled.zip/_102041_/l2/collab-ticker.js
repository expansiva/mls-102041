/// <mls fileReference="_102041_/l2/collab-ticker.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { nothing } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
let CollabTicker = class CollabTicker extends StateLitElement {
    constructor() {
        super(...arguments);
        this.text = 'C';
        this.element = 'p';
    }
    render() {
        if (!this.text)
            return nothing;
        const tag = this.element || 'p';
        return unsafeHTML(`<${tag} style="animation-delay:.3s">${this.text}</${tag}>`);
    }
};
__decorate([
    property({ attribute: 'text' })
], CollabTicker.prototype, "text", void 0);
__decorate([
    property({ attribute: 'element' })
], CollabTicker.prototype, "element", void 0);
CollabTicker = __decorate([
    customElement('collab-ticker')
], CollabTicker);
export { CollabTicker };
