/// <mls fileReference="_102041_/l2/collab-ticker.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { nothing } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let CollabTicker = class CollabTicker extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-ticker {
  display: block;
}
collab-ticker > p,
collab-ticker > h1,
collab-ticker > h2,
collab-ticker > h3,
collab-ticker > h4,
collab-ticker > h5,
collab-ticker > h6,
collab-ticker > span {
  width: 100%;
  height: 100%;
  color: #000000;
  white-space: nowrap;
  text-transform: lowercase;
  overflow: hidden;
  border-right: 0.15em solid #000000;
  opacity: 0;
  animation: type2 2s steps(20, end);
  animation-fill-mode: forwards;
  margin-bottom: 15px;
}
collab-ticker > p:last-child,
collab-ticker > h1:last-child,
collab-ticker > h2:last-child,
collab-ticker > h3:last-child,
collab-ticker > h4:last-child,
collab-ticker > h5:last-child,
collab-ticker > h6:last-child,
collab-ticker > span:last-child {
  animation: type3 2s steps(20, end), blink 0.3s step-end infinite alternate;
  animation-delay: 4s;
  animation-fill-mode: forwards;
}
collab-ticker > p i,
collab-ticker > h1 i,
collab-ticker > h2 i,
collab-ticker > h3 i,
collab-ticker > h4 i,
collab-ticker > h5 i,
collab-ticker > h6 i,
collab-ticker > span i {
  color: var(--collab-text-primary-color);
}
@keyframes type2 {
  0% {
    width: 0;
  }
  1% {
    opacity: 1;
  }
  99.9% {
    border-right: 0.15em solid orange;
  }
  100% {
    opacity: 1;
    border: none;
  }
}
@keyframes type3 {
  0% {
    width: 0;
  }
  1% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@keyframes blink {
  50% {
    border-color: transparent;
  }
}
`);
        this.text = 'C';
        this.element = 'p';
    }
    render() {
        if (!this.text)
            return nothing;
        const tag = this.element || 'p';
        return unsafeHTML(`<${tag} style="animation-delay:.3s">${this.text}</${tag}>`);
    }
};
__decorate([
    property({ attribute: 'text' })
], CollabTicker.prototype, "text", void 0);
__decorate([
    property({ attribute: 'element' })
], CollabTicker.prototype, "element", void 0);
CollabTicker = __decorate([
    customElement('collab-ticker')
], CollabTicker);
export { CollabTicker };
