/// <mls fileReference="_102041_/l2/collab-sticky-notification.ts" enhancement="_102020_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_en = {
    of: 'of',
    information: 'Information',
    alert: 'Alert',
    error: 'Error',
};
const message_pt = {
    of: 'de',
    information: 'Informação',
    alert: 'Alerta',
    error: 'Erro',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
let CollabStickyNotification = class CollabStickyNotification extends StateLitElement {
    constructor() {
        super(...arguments);
        this._messages = [];
        this._actualIndex = 0;
        this._isOpen = false;
        this._actualOptions = { clearOnClose: true, autoClose: false, timeToClose: 5000 };
        this.msg = messages['en'];
        this._defaultOptions = { clearOnClose: true, autoClose: false, timeToClose: 5000 };
    }
    get _mlsPage() { return this.closest('collab-page'); }
    add(message, typeMsg, options) {
        const newMessage = { text: message, type: typeMsg };
        this.setAttribute('mheight', '50');
        this._messages = [newMessage, ...this._messages];
        if (this._messages.length === 100)
            this._removeMsg(this._messages.length - 1);
        this._actualMessage = newMessage;
        this._actualIndex = 0;
        this._isOpen = true;
        const autoClose = typeMsg === 'information';
        if (options) {
            this._actualOptions = {
                autoClose: 'autoClose' in options ? options.autoClose : autoClose,
                clearOnClose: 'clearOnClose' in options ? options.clearOnClose : this._defaultOptions.clearOnClose,
                timeToClose: 'timeToClose' in options ? options.timeToClose : this._defaultOptions.timeToClose,
            };
            if (this._actualOptions.timeToClose)
                this._actualOptions = { ...this._actualOptions, autoClose: true };
        }
        else {
            this._actualOptions = { autoClose, clearOnClose: this._defaultOptions.clearOnClose, timeToClose: this._defaultOptions.timeToClose };
        }
        this._saveLocalStorageMessages(this._messages);
        if (this._actualOptions.autoClose)
            setTimeout(() => this.close(), this._actualOptions.timeToClose);
        if (this._mlsPage)
            this._mlsPage.layout();
    }
    close() {
        this._isOpen = false;
        this.removeAttribute('mheight');
        if (this._actualOptions.clearOnClose)
            this._removeMsg(this._actualIndex);
        this._actualIndex = 0;
        this._actualMessage = undefined;
        if (this._mlsPage)
            this._mlsPage.layout();
    }
    show() {
        const msg = this._getLocalStorageMessages();
        if (!msg || msg.length === 0)
            return;
        this._messages = msg;
        this._isOpen = true;
        this._actualIndex = 0;
        this._actualMessage = this._messages[0];
        if (this._mlsPage)
            this._mlsPage.layout();
    }
    updated() {
        this.classList.toggle('open', this._isOpen);
        ['information', 'alert', 'error'].forEach(cls => this.classList.remove(cls));
        if (this._actualMessage)
            this.classList.add(this._actualMessage.type);
    }
    render() {
        this.msg = messages[this.getMessageKey(messages)] || messages['en'];
        if (!this._isOpen || !this._actualMessage)
            return html `<div></div>`;
        const iconMap = {
            information: 'fa-circle-info',
            alert: 'fa-triangle-exclamation',
            error: 'fa-circle-exclamation',
        };
        return html `
            <div>
                <i class="icon-type fa ${iconMap[this._actualMessage.type]}"></i>
                <div class="controllers">
                    <i class="fa fa-caret-left" @click=${() => this._onLeftClick()}></i>
                    <span>${this._actualIndex + 1}</span>
                    <span>${this.msg.of}</span>
                    <span>${this._messages.length}</span>
                    <i class="fa fa-caret-right" @click=${() => this._onRightClick()}></i>
                </div>
                <span class="text-message" title="${this._actualMessage.text}">${this._actualMessage.text}</span>
                <i class="close-icon fa fa-times" @click=${() => this.close()}></i>
            </div>
        `;
    }
    _onLeftClick() {
        if (this._actualIndex < 1)
            return;
        this._actualIndex -= 1;
        this._actualMessage = this._messages[this._actualIndex];
    }
    _onRightClick() {
        if (this._actualIndex >= this._messages.length - 1)
            return;
        this._actualIndex += 1;
        this._actualMessage = this._messages[this._actualIndex];
    }
    _removeMsg(idx) {
        this._messages = this._messages.filter((_, i) => i !== idx);
        this._saveLocalStorageMessages(this._messages);
    }
    _getLocalStorageMessages() {
        const ls = localStorage.getItem('collab_sticky_notification');
        if (!ls)
            return [];
        const parsed = JSON.parse(ls);
        return Array.isArray(parsed) ? parsed : [];
    }
    _saveLocalStorageMessages(messages) {
        localStorage.setItem('collab_sticky_notification', JSON.stringify(messages));
    }
};
__decorate([
    state()
], CollabStickyNotification.prototype, "_messages", void 0);
__decorate([
    state()
], CollabStickyNotification.prototype, "_actualIndex", void 0);
__decorate([
    state()
], CollabStickyNotification.prototype, "_actualMessage", void 0);
__decorate([
    state()
], CollabStickyNotification.prototype, "_isOpen", void 0);
__decorate([
    state()
], CollabStickyNotification.prototype, "_actualOptions", void 0);
CollabStickyNotification = __decorate([
    customElement('collab-sticky-notification')
], CollabStickyNotification);
export { CollabStickyNotification };
