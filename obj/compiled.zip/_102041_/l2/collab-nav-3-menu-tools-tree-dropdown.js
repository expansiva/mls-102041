/// <mls fileReference="_102041_/l2/collab-nav-3-menu-tools-tree-dropdown.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
let CollabNav3MenuToolsTreeDropdown = class CollabNav3MenuToolsTreeDropdown extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-nav-3-menu-tools-tree-dropdown.list > div .sub-menu {
  display: none;
}
collab-nav-3-menu-tools-tree-dropdown.list > div .sub-menu > li::before {
  position: absolute;
  content: '\f054';
  font-family: 'Font Awesome 6 Free';
  font-weight: 900;
  right: 10px;
  font-size: 10px;
  top: 10px;
}
collab-nav-3-menu-tools-tree-dropdown.list > div .sub-menu > li .sub-menu-2 {
  display: none;
  list-style: none;
}
collab-nav-3-menu-tools-tree-dropdown.list > div .sub-menu > li .sub-menu-2 li {
  padding: 0.2rem;
}
collab-nav-3-menu-tools-tree-dropdown.list > div .sub-menu > li .sub-menu-2 li:hover {
  background-color: var(--collab-nav-bg-2);
}
collab-nav-3-menu-tools-tree-dropdown.list > div .dropdown-list-header {
  display: flex;
  gap: 0.3rem;
  padding: 0.3rem 0rem;
  align-items: center;
}
collab-nav-3-menu-tools-tree-dropdown.list > div .dropdown-list-header::before {
  position: absolute;
  content: '\f054';
  font-family: 'Font Awesome 6 Free';
  font-weight: 900;
  right: 10px;
  font-size: 10px;
  top: 10px;
}
collab-nav-3-menu-tools-tree-dropdown.list > div.opened .sub-menu {
  display: block;
}
collab-nav-3-menu-tools-tree-dropdown.list > div.opened .sub-menu li > div {
  display: flex;
  gap: 0.3rem;
}
collab-nav-3-menu-tools-tree-dropdown.list > div.opened .sub-menu > li.opened::before {
  content: '\f078';
}
collab-nav-3-menu-tools-tree-dropdown.list > div.opened .sub-menu > li.opened .sub-menu-2 {
  display: block;
}
collab-nav-3-menu-tools-tree-dropdown.list > div.opened .dropdown-list-header::before {
  content: '\f078';
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) {
  background-color: var(--collab-nav-bg-1);
  color: var(--collab-text-primary-color);
  box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 2px 2px;
  border-radius: 15%;
  width: 40px;
  height: 25px;
  font-size: 14px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  position: relative;
  user-select: none;
  transition: background-color 0.3s ease;
}
collab-nav-3-menu-tools-tree-dropdown:not(.list):hover {
  background-color: var(--collab-nav-bg-3);
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) .icon-drop {
  font-size: 10px;
  margin-left: 0.2rem;
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) .icon-menu > svg {
  width: 12px;
  height: 12px;
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) > span {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  display: flex !important;
  justify-content: center;
  align-items: center;
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) span .btn-menu {
  border: 1px solid #c3c3c3;
  position: absolute;
  display: none;
  top: 30px;
  right: -5px;
  font-size: 14px;
  font-weight: 400;
  background-color: var(--collab-nav-bg-1);
  color: var(--collab-text-primary-color);
  border-radius: 6px;
  margin-top: 5px;
  z-index: 9999;
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) span .btn-menu::before {
  position: absolute;
  display: inline-block;
  top: -14px;
  right: 9px;
  left: auto;
  border: 7px solid transparent;
  border-bottom: 7px solid #fff;
  content: "";
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) span .btn-menu.open {
  display: block;
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) span .btn-menu ul {
  list-style: none;
  padding-inline-start: 0;
  margin-block-start: 0;
  margin-block-end: 10px;
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) span .btn-menu ul > li.dropdown-sub-menu {
  position: relative;
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) span .btn-menu ul > li.dropdown-sub-menu svg {
  fill: currentColor;
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) span .btn-menu ul > li.dropdown-sub-menu::before {
  position: absolute;
  content: '\f054';
  font-family: 'Font Awesome 6 Free';
  font-weight: 900;
  right: 5px;
  font-size: 10px;
  top: 10px;
  color: var(--collab-text-primary-color);
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) span .btn-menu ul > li.dropdown-sub-menu > div {
  position: absolute;
  top: 0;
  left: 100%;
  padding: 5px 0;
  display: none;
  box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
  background-color: var(--collab-nav-bg-3);
  color: var(--collab-text-primary-color);
  white-space: nowrap;
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) span .btn-menu ul > li.dropdown-sub-menu:hover > div {
  display: block;
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) span .btn-menu ul li {
  padding: 0.5rem 1rem;
  white-space: nowrap;
  display: flex;
  gap: 0.3rem;
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) span .btn-menu ul li.menu-header {
  cursor: auto;
  text-transform: uppercase;
  font-size: 10px;
  border-bottom: 2px solid #cecece;
  font-weight: 100;
  color: #737373;
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) span .btn-menu ul li.active {
  background-color: var(--collab-nav-bg-3);
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) span .btn-menu ul li.active::before {
  position: absolute;
  content: '\f00c';
  font-family: 'Font Awesome 6 Free';
  font-weight: 900;
  left: 3px;
  font-size: 10px;
  top: 10px;
}
collab-nav-3-menu-tools-tree-dropdown:not(.list) span .btn-menu ul li:not(.menu-header):hover {
  background-color: var(--collab-nav-bg-3);
}
`);
        this.key = '';
        this.icon = '';
        this.selected = '';
        this.renderType = '';
        this._dropOpen = false;
        this._menuOpened = false;
        this._openedItems = new Set();
        this._onHostClick = (e) => {
            if (this._dropOpen) {
                this._dropOpen = false;
                this.classList.remove('open');
                return;
            }
            this._dropOpen = true;
            this.classList.add('open');
            this.parentElement?.querySelectorAll('.btn-menu').forEach(m => m.classList.remove('open'));
            this.parentElement?.querySelectorAll('collab-nav-3-menu-tools-dropdown').forEach(el => {
                if (el !== this)
                    el.classList.remove('open');
            });
        };
        this._onMenuHeaderClick = (e) => {
            const target = e.target;
            if (target.closest('li.sub-menu-2-item'))
                return;
            this._menuOpened = !this._menuOpened;
        };
        this._onDocumentClick = (e) => {
            if (!this.contains(e.target))
                this._closeDropdown();
        };
        this._onVisibilityChange = () => {
            if (document.visibilityState === 'hidden')
                this._closeDropdown();
        };
    }
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('click', this._onDocumentClick);
        document.addEventListener('visibilitychange', this._onVisibilityChange);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        document.removeEventListener('click', this._onDocumentClick);
        document.removeEventListener('visibilitychange', this._onVisibilityChange);
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.renderType === 'menu')
            this.classList.add('list');
    }
    render() {
        if (!this.tool)
            return nothing;
        return this.renderType === 'menu' ? this._renderAsMenu() : this._renderAsTool();
    }
    _renderAsTool() {
        if (!this.tool?.options)
            return nothing;
        const iconStr = this.icon && this.icon !== 'undefined' ? this.icon : '';
        return html `
            <span data-key="${this.key}" @click=${this._onHostClick}>
                ${this._iconTpl(iconStr, '', 'icon-menu')}
                <i class="fa-solid fa-caret-down icon-drop"></i>
                <div class="btn-menu ${this._dropOpen ? 'open' : ''}">
                    <ul>
                        <li class="menu-header">${this.key}</li>
                        ${this.tool.options.map((item, index) => {
            const hasSub = item.options && item.options.length > 0;
            return html `
                                <li class=${classMap({ 'dropdown-sub-menu': hasSub })}
                                    index="${index}"
                                    @click=${(e) => { if (!hasSub) {
                e.stopPropagation();
                this._onLeafClick(index);
            } }}>
                                    ${item.icon || item.class
                ? html `${this._iconTpl(item.icon, item.class)}<span>${item.text}</span>`
                : item.text}
                                    ${hasSub ? html `
                                        <div>
                                            <ul>
                                                ${item.options.map((sub, subIndex) => html `
                                                    <li @click=${(e) => { e.stopPropagation(); this._onSubLeafClick(index, subIndex); }}>
                                                        ${sub.icon || sub.class
                ? html `${this._iconTpl(sub.icon, sub.class)}<span>${sub.text}</span>`
                : sub.text}
                                                    </li>
                                                `)}
                                            </ul>
                                        </div>
                                    ` : nothing}
                                </li>
                            `;
        })}
                    </ul>
                </div>
            </span>
        `;
    }
    _renderAsMenu() {
        const iconStr = this.icon && this.icon !== 'undefined' ? this.icon : '';
        return html `
            <div data-key="${this.key}"
                 class=${classMap({ opened: this._menuOpened })}
                 @click=${this._onMenuHeaderClick}>
                <div class="dropdown-list-header">
                    ${this._iconTpl(iconStr, '')}
                    <span>${this.key.charAt(0).toUpperCase() + this.key.slice(1).toLowerCase()}</span>
                </div>
                <ul class="sub-menu">
                    ${this.tool?.options.map((opt, index) => html `
                        <li class=${classMap({ opened: this._openedItems.has(index) })}
                            @click=${(e) => { e.stopPropagation(); this._toggleMenuItem(index); }}>
                            <div>
                                ${this._iconTpl(opt.icon, opt.class)}
                                <span>${opt.text}</span>
                            </div>
                            <ul class="sub-menu-2">
                                ${opt.options.map((sub, subIndex) => html `
                                    <li class="sub-menu-2-item"
                                        @click=${(e) => { e.stopPropagation(); this._onMenuSubItemClick(index, subIndex); }}>
                                        <div>
                                            ${this._iconTpl(sub.icon, sub.class)}
                                            <span>${sub.text}</span>
                                        </div>
                                    </li>
                                `)}
                            </ul>
                        </li>
                    `)}
                </ul>
            </div>
        `;
    }
    _toggleMenuItem(index) {
        const next = new Set(this._openedItems);
        if (next.has(index))
            next.delete(index);
        else
            next.add(index);
        this._openedItems = next;
    }
    _onLeafClick(index) {
        if (!this.tool)
            return;
        this._dropOpen = false;
        this.classList.remove('open');
        this.selected = String(index);
        this.tool.selected = [index];
        if (typeof this.onClickTools !== 'function')
            throw new Error('onClickTools not found');
        this.onClickTools(this.key);
    }
    _onSubLeafClick(index, subIndex) {
        if (!this.tool)
            return;
        this._dropOpen = false;
        this.classList.remove('open');
        this.selected = [index, subIndex].toString();
        this.tool.selected = [index, subIndex];
        if (typeof this.onClickTools !== 'function')
            throw new Error('onClickTools not found');
        this.onClickTools(this.key);
    }
    _onMenuSubItemClick(index, subIndex) {
        if (!this.tool)
            return;
        this.selected = [index, subIndex].toString();
        this._menuOpened = false;
        this.tool.selected = [index, subIndex];
        if (typeof this.onClickTools !== 'function')
            throw new Error('onClickTools not found');
        this.onClickTools(this.key);
    }
    _closeDropdown() {
        this._dropOpen = false;
        this.classList.remove('open');
    }
    _iconTpl(str, className, extraClass = '') {
        const cls = [className || '', extraClass].filter(Boolean).join(' ');
        if (!str)
            return html `<i class="${cls}"></i>`;
        if (str.trim().startsWith('<svg'))
            return html `<span class="${cls}">${unsafeHTML(str)}</span>`;
        return html `<i class="fa ${cls}">${unsafeHTML('&#x' + str)}</i>`;
    }
};
__decorate([
    property({ attribute: 'key' })
], CollabNav3MenuToolsTreeDropdown.prototype, "key", void 0);
__decorate([
    property({ attribute: 'icon' })
], CollabNav3MenuToolsTreeDropdown.prototype, "icon", void 0);
__decorate([
    property({ attribute: 'selected' })
], CollabNav3MenuToolsTreeDropdown.prototype, "selected", void 0);
__decorate([
    property({ attribute: 'rendertype' })
], CollabNav3MenuToolsTreeDropdown.prototype, "renderType", void 0);
__decorate([
    state()
], CollabNav3MenuToolsTreeDropdown.prototype, "_dropOpen", void 0);
__decorate([
    state()
], CollabNav3MenuToolsTreeDropdown.prototype, "_menuOpened", void 0);
__decorate([
    state()
], CollabNav3MenuToolsTreeDropdown.prototype, "_openedItems", void 0);
CollabNav3MenuToolsTreeDropdown = __decorate([
    customElement('collab-nav-3-menu-tools-tree-dropdown')
], CollabNav3MenuToolsTreeDropdown);
export { CollabNav3MenuToolsTreeDropdown };
