/// <mls fileReference="_102041_/l2/collab-logo.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
let CollabLogo = class CollabLogo extends StateLitElement {
    render() {
        return html `
            <div class="logo">
                <div class="letter c1"></div>
                <div class="letter c2"></div>
            </div>
        `;
    }
};
CollabLogo = __decorate([
    customElement('collab-logo')
], CollabLogo);
export { CollabLogo };
