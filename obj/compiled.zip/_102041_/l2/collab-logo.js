/// <mls fileReference="_102041_/l2/collab-logo.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
let CollabLogo = class CollabLogo extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-logo {
  --width: 100px;
  --height: 100px;
  --width-container: 140px;
  --height-container: 140px;
  --animation-delay: 2s;
  --animation-duration: 2s;
  --letter-thickness: 20px;
  display: block;
}
collab-logo .logo {
  position: relative;
  width: var(--width-container);
  height: var(--height-container);
}
collab-logo .letter {
  position: absolute;
  width: var(--width);
  height: var(--height);
  border-radius: 50%;
  clip-path: inset(0 0 0 50%);
}
collab-logo .c1 {
  border: var(--letter-thickness) solid #4285F4;
  transform: scaleX(-1);
}
collab-logo .c2 {
  border: var(--letter-thickness) solid #EA4335;
  transform: translateX(70px) scaleX(-1);
  position: relative;
  animation: moveC2 var(--animation-duration) ease forwards var(--animation-delay);
}
@keyframes moveC2 {
  0% {
    transform: translateX(70px) scaleX(-1);
    opacity: 1;
  }
  25% {
    transform: translateX(90px);
    opacity: 0.4;
  }
  75% {
    transform: translateX(0) scaleX(1);
    opacity: 0.6;
  }
  100% {
    transform: translateX(0) scaleX(1);
    opacity: 1;
  }
}
`);
    }
    render() {
        return html `
            <div class="logo">
                <div class="letter c1"></div>
                <div class="letter c2"></div>
            </div>
        `;
    }
};
CollabLogo = __decorate([
    customElement('collab-logo')
], CollabLogo);
export { CollabLogo };
