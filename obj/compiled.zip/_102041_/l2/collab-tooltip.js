/// <mls fileReference="_102041_/l2/collab-tooltip.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let CollabTooltip = class CollabTooltip extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tooltip {
  position: absolute;
  will-change: transform;
  white-space: nowrap;
  top: 0px;
  left: 0px;
  transform: translate3d(-13px, 5px, 0px);
  z-index: 9999;
}
collab-tooltip > div {
  top: -8px;
  position: absolute;
  display: block;
  width: 100%;
  height: 0.4rem;
}
collab-tooltip > div::before {
  position: absolute;
  content: "";
  border-color: transparent;
  border-style: solid;
  bottom: -1px;
  left: 5px;
  border-width: 0 0.4rem 0.4rem;
  border-bottom-color: #000;
}
collab-tooltip > div.open-to-right::before {
  left: 0;
  content: none;
}
collab-tooltip > div.open-to-right::after {
  position: absolute;
  content: "";
  border-color: transparent;
  border-style: solid;
  right: 8px;
  bottom: -1px;
  border-width: 0 0.4rem 0.4rem;
  border-bottom-color: #000;
}
collab-tooltip > span {
  max-width: 200px;
  padding: 0.25rem 0.5rem;
  color: #fff;
  text-align: center;
  background-color: #000;
  border-radius: 0.25rem;
}
`);
        this._isMobile = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
        this._widthMarginOfError = 10;
        this.destroy = () => {
            this.innerHTML = '';
            this.style.top = '0px';
            this.style.left = '0px';
        };
        this._show = (evt) => {
            this.innerHTML = '';
            const el = evt.currentTarget['element'];
            if (!el)
                return;
            const title = el.getAttribute('data-tooltip');
            if (!title)
                return;
            const arrow = document.createElement('div');
            const content = document.createElement('span');
            content.innerHTML = title;
            this.appendChild(arrow);
            this.appendChild(content);
            const position = el.getBoundingClientRect();
            const docWidth = document.body.getBoundingClientRect().width;
            const contentWidth = content.getBoundingClientRect().width;
            if (contentWidth + position.left > docWidth - this._widthMarginOfError) {
                arrow.classList.add('open-to-right');
                this.style.left = (position.left + position.width / 2 - (contentWidth - 30)) + 'px';
                this.style.top = (position.top + 5 + position.height + 3) + 'px';
            }
            else {
                this.style.top = (position.top + position.height + 3) + 'px';
                this.style.left = (position.left + position.width / 2) + 'px';
            }
            if (this._isMobile) {
                clearTimeout(this._timeoutId);
                this._timeoutId = window.setTimeout(() => this.destroy(), 2000);
            }
        };
    }
    render() { return nothing; }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        document.body.appendChild(this);
    }
    tooltip(el) {
        el['element'] = el;
        el.addEventListener('mouseover', this._show, false);
        el.addEventListener('mouseleave', this.destroy, false);
    }
};
CollabTooltip = __decorate([
    customElement('collab-tooltip')
], CollabTooltip);
export { CollabTooltip };
