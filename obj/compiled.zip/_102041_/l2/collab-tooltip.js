/// <mls fileReference="_102041_/l2/collab-tooltip.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
let CollabTooltip = class CollabTooltip extends StateLitElement {
    constructor() {
        super(...arguments);
        this._isMobile = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
        this._widthMarginOfError = 10;
        this.destroy = () => {
            this.innerHTML = '';
            this.style.top = '0px';
            this.style.left = '0px';
        };
        this._show = (evt) => {
            this.innerHTML = '';
            const el = evt.currentTarget['element'];
            if (!el)
                return;
            const title = el.getAttribute('data-tooltip');
            if (!title)
                return;
            const arrow = document.createElement('div');
            const content = document.createElement('span');
            content.innerHTML = title;
            this.appendChild(arrow);
            this.appendChild(content);
            const position = el.getBoundingClientRect();
            const docWidth = document.body.getBoundingClientRect().width;
            const contentWidth = content.getBoundingClientRect().width;
            if (contentWidth + position.left > docWidth - this._widthMarginOfError) {
                arrow.classList.add('open-to-right');
                this.style.left = (position.left + position.width / 2 - (contentWidth - 30)) + 'px';
                this.style.top = (position.top + 5 + position.height + 3) + 'px';
            }
            else {
                this.style.top = (position.top + position.height + 3) + 'px';
                this.style.left = (position.left + position.width / 2) + 'px';
            }
            if (this._isMobile) {
                clearTimeout(this._timeoutId);
                this._timeoutId = window.setTimeout(() => this.destroy(), 2000);
            }
        };
    }
    render() { return nothing; }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        document.body.appendChild(this);
    }
    tooltip(el) {
        el['element'] = el;
        el.addEventListener('mouseover', this._show, false);
        el.addEventListener('mouseleave', this.destroy, false);
    }
};
CollabTooltip = __decorate([
    customElement('collab-tooltip')
], CollabTooltip);
export { CollabTooltip };
