/// <mls fileReference="_102041_/l2/collab-nav-3-menu-tools-link.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
let CollabNav3MenuToolsLink = class CollabNav3MenuToolsLink extends StateLitElement {
    constructor() {
        super(...arguments);
        this.key = '';
        this.renderType = '';
        this._onToolClick = () => {
            if (typeof this.onClickTools !== 'function')
                throw new Error('onClickTools not found');
            if (this._tooltipEl?.destroy)
                this._tooltipEl.destroy();
            this.onClickTools(this.key);
        };
        this._onMenuClick = () => {
            if (typeof this.onClickTools !== 'function')
                throw new Error('onClickTools not found');
            this.onClickTools(this.key);
        };
    }
    get _tooltipEl() { return document.querySelector('collab-tooltip'); }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.renderType === 'menu')
            this.classList.add('list');
    }
    updated() {
        const span = this.querySelector('span[data-tooltip]');
        if (this._tooltipEl?.tooltip && span)
            this._tooltipEl.tooltip(span);
    }
    render() {
        if (!this.tool)
            return nothing;
        const option = this.tool.options[0];
        if (!option)
            return nothing;
        return this.renderType === 'menu' ? this._renderAsMenu(option) : this._renderAsTool(option);
    }
    _renderAsTool(option) {
        return html `
            <span data-key="${this.key}" data-tooltip="${option.text}" @click=${this._onToolClick}>
                ${this._iconTpl(option.icon, option.class)}
                <i class="icon-link fa-solid fa-arrow-up-right-from-square"></i>
            </span>
        `;
    }
    _renderAsMenu(option) {
        return html `
            <div data-key="${this.key}" @click=${this._onMenuClick}>
                ${this._iconTpl(option.icon, option.class)}
                <span>${option.text.trim()} ...</span>
            </div>
        `;
    }
    _iconTpl(str, className) {
        const cls = className || '';
        if (!str)
            return html `<i class="${cls}"></i>`;
        if (str.trim().startsWith('<svg'))
            return html `<span class="${cls}">${unsafeHTML(str)}</span>`;
        return html `<i class="fa ${cls}">${unsafeHTML('&#x' + str)}</i>`;
    }
};
__decorate([
    property({ attribute: 'key' })
], CollabNav3MenuToolsLink.prototype, "key", void 0);
__decorate([
    property({ attribute: 'rendertype' })
], CollabNav3MenuToolsLink.prototype, "renderType", void 0);
CollabNav3MenuToolsLink = __decorate([
    customElement('collab-nav-3-menu-tools-link')
], CollabNav3MenuToolsLink);
export { CollabNav3MenuToolsLink };
