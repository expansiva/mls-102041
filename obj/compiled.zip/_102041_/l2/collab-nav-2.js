/// <mls fileReference="_102041_/l2/collab-nav-2.ts" enhancement="_102020_/l2/enhancementAura.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_en = {
    start: 'Start',
};
const message_pt = {
    start: 'Início',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { repeat } from 'lit/directives/repeat.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
let CollabNav2 = class CollabNav2 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.level = 0;
        this.status = '';
        this._services = [];
        this._controllersVisible = false;
        this._scrollLeft = false;
        this._scrollRight = false;
        this._badgesState = {};
        this._alreadyLoadedServices = false;
        this._onlyFirstTime = { left: false, right: false };
        this.state_ = {
            0: { left: '', right: '' }, 1: { left: '', right: '' }, 2: { left: '', right: '' }, 3: { left: '', right: '' },
            4: { left: '', right: '' }, 5: { left: '', right: '' }, 6: { left: '', right: '' }, 7: { left: '', right: '' },
        };
        this.msg = messages['en'];
        this._staticService = ['_100529_service_start', '_100529_service_home'];
        this._staticServices = {
            0: { left: [{ widget: '_100529_service_start', state: 'foreground', icon: '&#xf059', tooltip: this.msg.start, isStatic: true, visible: true }], right: [] },
            1: { left: [{ widget: '_100529_service_start', state: 'foreground', icon: '&#xf059', tooltip: this.msg.start, isStatic: true, visible: true }], right: [] },
            2: { left: [{ widget: '_100529_service_start', state: 'foreground', icon: '&#xf059', tooltip: this.msg.start, isStatic: true, visible: true }], right: [] },
            3: { left: [{ widget: '_100529_service_start', state: 'foreground', icon: '&#xf059', tooltip: this.msg.start, isStatic: true, visible: true }], right: [] },
            4: { left: [{ widget: '_100529_service_start', state: 'foreground', icon: '&#xf059', tooltip: this.msg.start, isStatic: true, visible: true }], right: [] },
            5: { left: [{ widget: '_100529_service_start', state: 'foreground', icon: '&#xf059', tooltip: this.msg.start, isStatic: true, visible: true }], right: [] },
            6: { left: [{ widget: '_100529_service_start', state: 'foreground', icon: '&#xf059', tooltip: this.msg.start, isStatic: true, visible: true }], right: [] },
            7: { left: [{ widget: '_100529_service_start', state: 'foreground', icon: '&#xf059', tooltip: this.msg.start, isStatic: true, visible: true }], right: [] },
        };
    }
    get position() { return this.getAttribute('toolbarposition') || 'left'; }
    layout() { this._verifyControllers(); }
    toogleBadge(show, path, saveState = true) {
        if (saveState)
            this._badgesState[path] = show;
        const item = this.querySelector(`collab-nav-2-item[data-service="${path}"]`);
        if (item)
            item.classList.toggle('notification', show);
    }
    async getUserServices() {
        const s = await this._getUserServices();
        return JSON.parse(JSON.stringify(s));
    }
    async addService(service, level, position) {
        if (!this.actualServices)
            this.actualServices = await this._getUserServices();
        const already = this.actualServices[level][position].find(s => s.widget === service.widget);
        if (already)
            throw new Error(`Service ${service.widget} already added`);
        this.actualServices[level][position].push(service);
        this._refreshOppositeNav2(this.actualServices);
        if (this.level === level) {
            this._services = [...this.actualServices[level][this.position]];
        }
    }
    async removeService(index, level, position) {
        if (!this.actualServices)
            this.actualServices = await this._getUserServices();
        const exists = this.actualServices[level][position][index];
        if (!exists)
            throw new Error(`Service index ${index} does not exist`);
        this.actualServices[level][position].splice(index, 1);
        this._refreshOppositeNav2(this.actualServices);
        if (this.level === level) {
            this._services = [...this.actualServices[level][this.position]];
        }
    }
    async moveService(fromIndex, toIndex, level, position) {
        if (!this.actualServices)
            this.actualServices = await this._getUserServices();
        const from = this.actualServices[level][position][fromIndex];
        if (!from)
            throw new Error(`Service from index ${fromIndex} does not exist`);
        const to = this.actualServices[level][position][toIndex];
        if (!to)
            throw new Error(`Service to index ${toIndex} does not exist`);
        if (fromIndex === toIndex)
            return;
        this.actualServices[level][position].splice(fromIndex, 1);
        this.actualServices[level][position].splice(toIndex, 0, from);
        this._refreshOppositeNav2(this.actualServices);
        if (this.level === level) {
            this._services = [...this.actualServices[level][this.position]];
        }
    }
    async updateClassName(index, newClass, level, position) {
        if (!this.actualServices)
            this.actualServices = await this._getUserServices();
        const exists = this.actualServices[level][position][index];
        if (!exists)
            throw new Error(`Service index ${index} does not exist`);
        if (!newClass)
            delete exists.classname;
        else
            exists.classname = newClass;
        this._refreshOppositeNav2(this.actualServices);
        if (this.level === level) {
            this._services = [...this.actualServices[level][this.position]];
        }
    }
    firstUpdated() {
        this.actualServices = this._staticServices;
        this._services = (this.actualServices[this.level]?.[this.position]) || [];
        this._setEvents();
    }
    async updated(changed) {
        if (changed.has('level')) {
            await this._renderServiceByLevel();
            this._onStatusChanged();
        }
        if (changed.has('status') && this.status === 'start')
            this._onStatusChanged();
        if (changed.has('status') && this.status === 'enabled') {
            await this._renderAfterEnabled();
            this._onStatusChanged();
        }
        this._setShortCuts();
        this._verifyControllers();
    }
    render() {
        this.msg = messages[this.getMessageKey(messages)] || messages['en'];
        return html `
            <div class="collab-nav-2-container">
                <div class="controller left ${classMap({ visible: this._controllersVisible, disabled: !this._scrollLeft })}"
                     @click=${() => this._onControllerClick('left')}>
                    <i class="fa fa-chevron-left"></i>
                </div>
                <div class="collab-nav-2-items" @scroll=${() => this._checkControllersOnScroll()}>
                    ${repeat(this._services, s => s.widget, s => this._renderItem(s))}
                </div>
                <div class="controller right ${classMap({ visible: this._controllersVisible, disabled: !this._scrollRight })}"
                     @click=${() => this._onControllerClick('right')}>
                    <i class="fa fa-chevron-right"></i>
                </div>
            </div>
        `;
    }
    _renderItem(item) {
        return html `
            <collab-nav-2-item
                data-service="${item.widget}"
                data-tooltip="${item.tooltip}"
                ?isstatic="${item.isStatic}"
                visible="${item.visible}"
                class=${classMap({
            notification: !!this._badgesState[item.widget],
            [item.classname || '']: !!item.classname,
            enabled: false,
            disabled: false,
        })}
                style="${item.visible ? '' : 'display:none'}"
                @click=${() => this._onItemClick(item)}>
                <i class="fa">${unsafeHTML(item.icon)}</i>
                <span>${item.tooltip}</span>
            </collab-nav-2-item>
        `;
    }
    _setEvents() {
        this.containerItens = this.querySelector('.collab-nav-2-items');
        window.addEventListener('resize', () => this._verifyControllers());
        if (this.containerItens)
            this.containerItens.onscroll = () => this._checkControllersOnScroll();
    }
    _onItemClick(item) {
        this.state_[this.level][this.position] = item.widget;
        const el = this.querySelector(`collab-nav-2-item[data-service="${item.widget}"]`);
        if (el)
            this._selectItem(el, item.widget);
    }
    _selectItem(el, service) {
        const lastSelected = this.querySelector('collab-nav-2-item.selected')?.getAttribute('data-service');
        this.querySelectorAll('collab-nav-2-item').forEach(i => i.classList.remove('selected'));
        el.classList.add('selected');
        const mls = window.mls;
        if (mls?.setActualService)
            mls.setActualService(service);
        if (mls?.setActualPosition)
            mls.setActualPosition(this.position);
        this._verifyControllers();
        this._fireToolbarSelected(service, lastSelected);
        this._fireSelectedChangeNav3(service);
    }
    _fireToolbarSelected(to, from) {
        const params = { level: this.level, position: this.position, from, to };
        if (window['traceLifecycle'])
            console.info(`firing: ToolBarSelected level:${this.level} | position: ${this.position} | service: ${to}`);
        window.mls?.events?.fire([this.level], ['ToolBarSelected'], JSON.stringify(params));
    }
    _fireSelectedChangeNav3(service, nav2) {
        const nav3 = nav2 ? nav2.nextElementSibling : this.nextElementSibling;
        if (nav3) {
            nav3.setAttribute('level', String(this.level));
            nav3.setAttribute('data-service', service);
        }
    }
    _onControllerClick(dir) {
        const items = this.querySelector('.collab-nav-2-items');
        if (!items)
            return;
        items.scrollLeft += dir === 'left' ? -80 : 80;
        this._verifyControllers();
    }
    _verifyControllers() {
        const items = this.querySelector('.collab-nav-2-items');
        if (!items)
            return;
        const { scrollWidth, clientWidth } = items;
        if (clientWidth < 40) {
            this._controllersVisible = false;
            return;
        }
        const eff = this._controllersVisible ? clientWidth + 20 : clientWidth;
        this._controllersVisible = scrollWidth > eff;
        this._checkControllersOnScroll();
    }
    _checkControllersOnScroll() {
        const items = this.querySelector('.collab-nav-2-items');
        if (!items)
            return;
        this._scrollLeft = items.scrollLeft > 0;
        this._scrollRight = items.clientWidth + items.scrollLeft < items.scrollWidth;
    }
    _setShortCuts() {
        const items = this.querySelectorAll('collab-nav-2-item:not([visible=false])');
        items.forEach((item, index) => {
            const original = item['tooltip'] || item.getAttribute('data-tooltip') || '';
            if (index > 9) {
                item.setAttribute('data-tooltip', original);
                return;
            }
            const newIndex = index === 9 ? 0 : index + 1;
            const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
            const shortcut = this.position === 'left'
                ? (isMac ? `⌃+⌥+${newIndex}` : `Ctrl+Alt+${newIndex}`)
                : (isMac ? `⌥+⇧+${newIndex}` : `Alt+Shift+${newIndex}`);
            item.setAttribute('data-tooltip', `${original} (${shortcut})`);
        });
    }
    async _renderServiceByLevel() {
        if (!this.actualServices)
            this.actualServices = await this._getUserServices();
        const reasons = this._getReasons();
        const services = this.actualServices[this.level]?.[this.position] || [];
        this._services = [...services];
    }
    async _renderAfterEnabled() {
        this.actualServices = await this._getUserServices();
        this._setInitialServicesAfterEnabled();
        this._services = [...(this.actualServices[this.level]?.[this.position] || [])];
        await this.updateComplete;
        this._activeLastServiceClicked();
    }
    _onStatusChanged() {
        const page = document.querySelector('collab-page');
        const nav3 = page?.querySelector(`collab-nav-3[toolbarposition="${this.position}"]`);
        if (nav3)
            nav3.setAttribute('status', this.status);
        this.querySelectorAll('collab-nav-2-item').forEach((item, index) => {
            const isStatic = item.getAttribute('isstatic') === 'true';
            item.classList.remove('enabled', 'disabled');
            if (this.status === 'start' && isStatic && index === 0) {
                item.classList.add('enabled');
                const last = this.state_[this.level][this.position];
                const lastEl = this.querySelector(`collab-nav-2-item[data-service="${last}"]`);
                const isLastStatic = lastEl?.getAttribute('isstatic') === 'true';
                if (!last || isLastStatic)
                    item.click();
            }
            else if (this.status === 'start') {
                item.classList.add('disabled');
            }
            else if (this.status !== 'null') {
                item.classList.add(this.status);
            }
        });
    }
    _setInitialServicesAfterEnabled() {
        if (this._onlyFirstTime[this.position])
            return;
        const START = '_100529_service_start';
        const s = { ...this.state_, 7: { left: '', right: '' } };
        for (const key in this.actualServices) {
            const svc = this.actualServices[key];
            if (key === '7')
                s[key].left = START;
            else if (s[key].left === '' || s[key].left === START)
                s[key].left = svc.left[1]?.widget || START;
            if (s[key].right === '')
                s[key].right = svc.right[0]?.widget;
        }
        this._onlyFirstTime[this.position] = true;
        this.state_ = s;
    }
    _activeLastServiceClicked() {
        const last = this.state_[this.level][this.position];
        if (!last) {
            this._fireSelectedChangeNav3(last);
            return;
        }
        const el = this.querySelector(`collab-nav-2-item[data-service="${last}"]`);
        const isStaticSelected = el?.getAttribute('isstatic') === 'true' && el?.classList.contains('selected');
        if (el && !isStaticSelected)
            this._selectItem(el, last);
    }
    async _getUserServices() {
        const nav1 = this.closest('collab-page')?.querySelector('collab-nav-1');
        if (!nav1?.actualServices)
            return {};
        return nav1.actualServices;
    }
    _getReasons() {
        const nav1 = this.closest('collab-page')?.querySelector('collab-nav-1');
        return nav1?.reasons || {};
    }
    _refreshOppositeNav2(services) {
        const op = this.position === 'left' ? 'right' : 'left';
        const other = document.querySelector(`collab-nav-2[toolbarposition="${op}"]`);
        if (other)
            other.actualServices = services;
    }
};
__decorate([
    property({ type: Number, attribute: 'level' })
], CollabNav2.prototype, "level", void 0);
__decorate([
    property({ attribute: 'status' })
], CollabNav2.prototype, "status", void 0);
__decorate([
    state()
], CollabNav2.prototype, "_services", void 0);
__decorate([
    state()
], CollabNav2.prototype, "_controllersVisible", void 0);
__decorate([
    state()
], CollabNav2.prototype, "_scrollLeft", void 0);
__decorate([
    state()
], CollabNav2.prototype, "_scrollRight", void 0);
CollabNav2 = __decorate([
    customElement('collab-nav-2')
], CollabNav2);
export { CollabNav2 };
