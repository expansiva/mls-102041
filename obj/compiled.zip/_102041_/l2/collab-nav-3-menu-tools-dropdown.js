/// <mls fileReference="_102041_/l2/collab-nav-3-menu-tools-dropdown.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
let CollabNav3MenuToolsDropdown = class CollabNav3MenuToolsDropdown extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-nav-3-menu-tools-dropdown.list > div .sub-menu {
  display: none;
}
collab-nav-3-menu-tools-dropdown.list > div .dropdown-list-header {
  display: flex;
  gap: 0.3rem;
  padding: 0.3rem 0rem;
  align-items: center;
}
collab-nav-3-menu-tools-dropdown.list > div .dropdown-list-header::before {
  position: absolute;
  content: '\f054';
  font-family: 'Font Awesome 6 Free';
  font-weight: 900;
  right: 10px;
  font-size: 10px;
  top: 10px;
}
collab-nav-3-menu-tools-dropdown.list > div.opened .sub-menu {
  display: block;
}
collab-nav-3-menu-tools-dropdown.list > div.opened .sub-menu li > div {
  display: flex;
  gap: 0.3rem;
  position: relative;
}
collab-nav-3-menu-tools-dropdown.list > div.opened .sub-menu li.selected::before {
  position: absolute;
  content: '\f00c';
  font-family: 'Font Awesome 6 Free';
  font-weight: 900;
  left: 3px;
  font-size: 10px;
  top: 10px;
}
collab-nav-3-menu-tools-dropdown.list > div.opened .dropdown-list-header::before {
  content: '\f078';
}
collab-nav-3-menu-tools-dropdown:not(.list) {
  background-color: var(--collab-nav-bg-1);
  color: var(--collab-text-primary-color);
  box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 2px 2px;
  border-radius: 15%;
  width: 40px;
  height: 25px;
  font-size: 14px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  position: relative;
  user-select: none;
  transition: background-color 0.3s ease;
}
collab-nav-3-menu-tools-dropdown:not(.list):hover {
  background-color: var(--collab-nav-bg-3);
}
collab-nav-3-menu-tools-dropdown:not(.list) .icon-drop {
  font-size: 10px;
  margin-left: 0.2rem;
}
collab-nav-3-menu-tools-dropdown:not(.list) .icon-menu > svg {
  width: 12px;
  height: 12px;
}
collab-nav-3-menu-tools-dropdown:not(.list) > span {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  display: flex !important;
  justify-content: center;
  align-items: center;
}
collab-nav-3-menu-tools-dropdown:not(.list) span .btn-menu {
  border: 1px solid #c3c3c3;
  position: absolute;
  display: none;
  top: 30px;
  right: -5px;
  font-size: 14px;
  font-weight: 400;
  background-color: var(--collab-nav-bg-1);
  color: var(--collab-text-primary-color);
  border-radius: 6px;
  margin-top: 5px;
  z-index: 9999;
}
collab-nav-3-menu-tools-dropdown:not(.list) span .btn-menu::before {
  position: absolute;
  display: inline-block;
  top: -14px;
  right: 9px;
  left: auto;
  border: 7px solid transparent;
  border-bottom: 7px solid #c3c3c3;
  content: "";
}
collab-nav-3-menu-tools-dropdown:not(.list) span .btn-menu.open {
  display: block;
}
collab-nav-3-menu-tools-dropdown:not(.list) span .btn-menu ul {
  list-style: none;
  padding-inline-start: 0;
  margin-block-start: 0;
  margin-block-end: 10px;
}
collab-nav-3-menu-tools-dropdown:not(.list) span .btn-menu ul li {
  position: relative;
  padding: 0.5rem 1rem;
  white-space: nowrap;
  display: flex;
  gap: 0.3rem;
}
collab-nav-3-menu-tools-dropdown:not(.list) span .btn-menu ul li.menu-header {
  cursor: auto;
  text-transform: uppercase;
  font-size: 10px;
  border-bottom: 2px solid #c3c3c3;
  font-weight: 100;
  color: #737373;
}
collab-nav-3-menu-tools-dropdown:not(.list) span .btn-menu ul li.active {
  background-color: var(--collab-nav-bg-3);
}
collab-nav-3-menu-tools-dropdown:not(.list) span .btn-menu ul li.active::before {
  position: absolute;
  content: '\f00c';
  font-family: 'Font Awesome 6 Free';
  font-weight: 900;
  left: 3px;
  font-size: 10px;
  top: 10px;
}
collab-nav-3-menu-tools-dropdown:not(.list) span .btn-menu ul li:not(.menu-header):hover {
  background-color: var(--collab-nav-bg-3);
}
`);
        this.key = '';
        this.icon = '';
        this.selected = 0;
        this.renderType = '';
        this._dropOpen = false;
        this._menuOpened = false;
        this._onHostClick = (e) => {
            if (this._dropOpen) {
                this._dropOpen = false;
                this.classList.remove('open');
                return;
            }
            this._dropOpen = true;
            this.classList.add('open');
            this.parentElement?.querySelectorAll('.btn-menu').forEach(m => m.classList.remove('open'));
            this.parentElement?.querySelectorAll('collab-nav-3-menu-tools-dropdown').forEach(el => {
                if (el !== this)
                    el._closeDropdown();
            });
        };
        this._onMenuHeaderClick = () => {
            this._menuOpened = !this._menuOpened;
        };
        this._onDocumentClick = (e) => {
            if (!this.contains(e.target))
                this._closeDropdown();
        };
        this._onVisibilityChange = () => {
            if (document.visibilityState === 'hidden')
                this._closeDropdown();
        };
    }
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('click', this._onDocumentClick);
        document.addEventListener('visibilitychange', this._onVisibilityChange);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        document.removeEventListener('click', this._onDocumentClick);
        document.removeEventListener('visibilitychange', this._onVisibilityChange);
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.renderType === 'menu') {
            this.classList.add('list');
            this._syncFromToolbar();
        }
    }
    render() {
        if (!this.tool)
            return nothing;
        return this.renderType === 'menu' ? this._renderAsMenu() : this._renderAsTool();
    }
    _renderAsTool() {
        if (!this.tool?.options)
            return nothing;
        const useIconAttr = this.icon && this.icon !== 'undefined';
        const iconStr = useIconAttr ? this.icon : this.tool.options[this.selected]?.icon;
        const iconCls = useIconAttr ? '' : (this.tool.options[this.selected]?.class || '');
        return html `
            <span data-key="${this.key}" @click=${this._onHostClick}>
                ${this._iconTpl(iconStr, iconCls, 'icon-menu')}
                <i class="fa-solid fa-caret-down icon-drop"></i>
                <div class="btn-menu ${this._dropOpen ? 'open' : ''}">
                    <ul>
                        <li class="menu-header">${this.key}</li>
                        ${this.tool.options.map((item, index) => html `
                            <li class=${classMap({ active: this.selected === index })}
                                index="${index}"
                                @click=${(e) => { e.stopPropagation(); this._onOptionClick(index, item); }}>
                                ${item.icon || item.class
            ? html `${this._iconTpl(item.icon, item.class)}<span>${item.text}</span>`
            : item.text}
                            </li>
                        `)}
                    </ul>
                </div>
            </span>
        `;
    }
    _renderAsMenu() {
        const option = this.tool?.options[this.selected];
        if (!option)
            return nothing;
        return html `
            <div data-key="${this.key}"
                 class=${classMap({ opened: this._menuOpened })}
                 @click=${this._onMenuHeaderClick}>
                <div class="dropdown-list-header">
                    ${this._iconTpl(option.icon, option.class)}
                    <span>${this.key.charAt(0).toUpperCase() + this.key.slice(1).toLowerCase()}</span>
                    <span> : ${option.text}</span>
                </div>
                <ul class="sub-menu">
                    ${this.tool?.options.map((opt, index) => html `
                        <li class=${classMap({ selected: index === this.selected })}
                            @click=${(e) => { e.stopPropagation(); this._onMenuItemClick(index); }}>
                            <div>
                                ${this._iconTpl(opt.icon, opt.class)}
                                <span>${opt.text}</span>
                            </div>
                        </li>
                    `)}
                </ul>
            </div>
        `;
    }
    _onOptionClick(index, item) {
        if (!this.tool)
            return;
        this._dropOpen = false;
        this.classList.remove('open');
        this.selected = index;
        this.tool.selected = index;
        if (typeof this.onClickTools !== 'function')
            throw new Error('onClickTools not found');
        this.onClickTools(this.key);
    }
    _onMenuItemClick(index) {
        if (!this.tool)
            return;
        const similar = this._findToolbarCounterpart();
        if (similar)
            similar.setAttribute('selected', index.toString());
        this.selected = index;
        this._menuOpened = false;
        this.tool.selected = index;
        if (typeof this.onClickTools !== 'function')
            throw new Error('onClickTools not found');
        this.onClickTools(this.key);
    }
    _closeDropdown() {
        this._dropOpen = false;
        this.classList.remove('open');
    }
    _syncFromToolbar() {
        const similar = this._findToolbarCounterpart();
        if (similar) {
            const sel = similar.getAttribute('selected');
            if (sel)
                this.selected = +sel;
        }
    }
    _findToolbarCounterpart() {
        return this.closest('collab-nav-3-menu')
            ?.querySelector('.tools')
            ?.querySelector(`collab-nav-3-menu-tools-dropdown[key="${this.key}"]`);
    }
    _iconTpl(str, className, extraClass = '') {
        const cls = [className || '', extraClass].filter(Boolean).join(' ');
        if (!str)
            return html `<i class="${cls}"></i>`;
        if (str.trim().startsWith('<svg'))
            return html `<span class="${cls}">${unsafeHTML(str)}</span>`;
        return html `<i class="fa ${cls}">${unsafeHTML('&#x' + str)}</i>`;
    }
};
__decorate([
    property({ attribute: 'key' })
], CollabNav3MenuToolsDropdown.prototype, "key", void 0);
__decorate([
    property({ attribute: 'icon' })
], CollabNav3MenuToolsDropdown.prototype, "icon", void 0);
__decorate([
    property({ type: Number, attribute: 'selected' })
], CollabNav3MenuToolsDropdown.prototype, "selected", void 0);
__decorate([
    property({ attribute: 'rendertype' })
], CollabNav3MenuToolsDropdown.prototype, "renderType", void 0);
__decorate([
    state()
], CollabNav3MenuToolsDropdown.prototype, "_dropOpen", void 0);
__decorate([
    state()
], CollabNav3MenuToolsDropdown.prototype, "_menuOpened", void 0);
CollabNav3MenuToolsDropdown = __decorate([
    customElement('collab-nav-3-menu-tools-dropdown')
], CollabNav3MenuToolsDropdown);
export { CollabNav3MenuToolsDropdown };
