/// <mls fileReference="_102041_/l2/collab-nav-3-menu.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_en = {
    about: 'About',
    aboutThisService: 'About this Service',
    reference: 'Reference',
    level: 'Level',
    position: 'Position',
    preview: 'Preview',
};
const message_pt = {
    about: 'Sobre',
    aboutThisService: 'Sobre este serviço',
    reference: 'Referência',
    level: 'Nível',
    position: 'Posição',
    preview: 'Pré-visualização',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import '/_102041_/l2/collab-nav-3-menu-tools-link.js';
import '/_102041_/l2/collab-tooltip.js';
import '/_102041_/l2/collab-nav-3-menu-tools-cycle.js';
import '/_102041_/l2/collab-nav-3-menu-tools-dropdown.js';
import '/_102041_/l2/collab-nav-3-menu-tools-tree-dropdown.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
let CollabNav3Menu = class CollabNav3Menu extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-nav-3-menu {
  color: var(--collab-nav-color-active);
}
collab-nav-3-menu a {
  color: var(--collab-nav-color-active);
}
collab-nav-3-menu .collab-nav-3-menu-action {
  clear: both;
  transition: max-height 0.2s ease-out;
  height: calc(100vh - 104px);
  overflow: auto;
  background: var(--bg-primary-color);
  color: var(--text-primary-color);
}
collab-nav-3-menu > div {
  background-color: var(--collab-nav-bg-3);
  box-shadow: 1px 1px 4px 0 rgba(0, 0, 0, 0.1);
  width: 100%;
  height: 40px;
  position: relative;
  z-index: 3;
}
collab-nav-3-menu > div .container.hidden {
  display: none;
}
collab-nav-3-menu > div .container .tabs,
collab-nav-3-menu > div .menu-list,
collab-nav-3-menu > div .sub-menu {
  margin: 0;
  padding: 0;
  list-style: none;
  overflow: hidden;
  background-color: var(--collab-nav-bg-3);
  box-shadow: rgba(50, 50, 93, 0.25) 0px 30px 60px -12px, rgba(0, 0, 0, 0.3) 0px 18px 36px -18px;
}
collab-nav-3-menu > div .container .tabs > li,
collab-nav-3-menu > div .menu-list > li,
collab-nav-3-menu > div .sub-menu > li {
  position: relative;
  display: block;
  cursor: pointer;
  background: var(--collab-nav-bg-3);
  font-size: 14px;
}
collab-nav-3-menu > div .container .tabs > li > div,
collab-nav-3-menu > div .menu-list > li > div,
collab-nav-3-menu > div .sub-menu > li > div {
  display: block;
  padding: 0.5rem 1.25rem;
  text-decoration: none;
}
collab-nav-3-menu > div .container .tabs > li > div:hover,
collab-nav-3-menu > div .menu-list > li > div:hover,
collab-nav-3-menu > div .sub-menu > li > div:hover {
  background-color: var(--bg-primary-color-lighter);
}
collab-nav-3-menu .menu-list {
  clear: both;
  transition: max-height 0.2s ease-out;
  position: absolute;
  width: 100%;
  z-index: 9999;
  overflow: auto !important;
}
collab-nav-3-menu .menu-list li.with-drop .sub-menu {
  display: none;
}
collab-nav-3-menu .menu-list li.with-drop::before {
  position: absolute;
  content: '\f054';
  font-family: 'Font Awesome 6 Free';
  font-weight: 900;
  right: 10px;
  font-size: 10px;
  top: 10px;
}
collab-nav-3-menu .menu-list li.with-drop.opened .sub-menu {
  display: block;
}
collab-nav-3-menu .menu-list li.with-drop.opened .sub-menu li > div {
  display: flex;
  gap: 0.3rem;
}
collab-nav-3-menu .menu-list li.with-drop.opened::before {
  content: '\f078';
}
collab-nav-3-menu .menu-list .icon-menu-list {
  height: 14px;
  width: 14px;
  margin-right: 0.3rem;
}
collab-nav-3-menu .menu-list svg {
  height: 14px;
  width: 14px;
}
collab-nav-3-menu .container {
  display: flex;
  justify-content: normal;
}
collab-nav-3-menu .container.checked .content {
  display: none;
}
collab-nav-3-menu .container .menu {
  cursor: pointer;
  float: right;
  padding: 18px 20px;
  position: relative;
  user-select: none;
}
collab-nav-3-menu .container .menu .menu-icon {
  background: var(--collab-nav-color-active);
  display: block;
  height: 2px;
  position: relative;
  transition: background 0.2s ease-out;
  width: 18px;
}
collab-nav-3-menu .container .menu .menu-icon::before,
collab-nav-3-menu .container .menu .menu-icon::after {
  background: var(--collab-nav-color-active);
  content: '';
  display: block;
  height: 100%;
  position: absolute;
  transition: all 0.2s ease-out;
  width: 100%;
}
collab-nav-3-menu .container .menu .menu-icon::before {
  top: 5px;
}
collab-nav-3-menu .container .menu .menu-icon::after {
  top: -5px;
}
collab-nav-3-menu .container .menu .menu-btn {
  display: none;
}
collab-nav-3-menu .container .menu .menu-btn:checked ~ .menu-icon {
  background: transparent;
}
collab-nav-3-menu .container .menu .menu-btn:checked ~ .menu-icon:before {
  top: 0;
  transform: rotate(-45deg);
}
collab-nav-3-menu .container .menu .menu-btn:checked ~ .menu-icon:after {
  top: 0;
  transform: rotate(45deg);
}
collab-nav-3-menu .container .content {
  display: flex;
  justify-content: space-between;
  flex-wrap: nowrap;
  flex: 1;
}
collab-nav-3-menu .container .content .title {
  font-size: 0.9em;
  font-weight: bold;
  display: flex;
  justify-content: center;
  align-items: center;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
  flex: 1;
  cursor: pointer;
}
collab-nav-3-menu .container .content .title a {
  text-decoration: none;
}
collab-nav-3-menu .container .content .title i {
  margin-right: 0.5rem;
}
collab-nav-3-menu .container .content .tools {
  display: flex;
  gap: 0.5rem;
  align-items: center;
  padding-right: 10px;
}
collab-nav-3-menu .container .content .tabs.compact li:not(.icon-back-button) {
  display: none !important;
}
collab-nav-3-menu .container .content .tabs {
  margin: 0;
  display: flex;
  align-items: center;
  list-style: none;
  padding: 0 0.5rem;
  margin-right: 10px;
  white-space: nowrap;
}
collab-nav-3-menu .container .content .tabs li.icon-back-button {
  cursor: pointer;
  border: 1px solid #cecece;
  width: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 30px;
  border-radius: 10px;
}
collab-nav-3-menu .container .content .tabs li.icon-back-button svg {
  width: 12px;
  height: 12px;
}
collab-nav-3-menu .container .content .tabs li.back-button-hidden {
  display: none;
}
collab-nav-3-menu .container .content .tabs li:not(.icon-back-button) {
  border-right: 1px solid #cecece;
  cursor: pointer;
  padding: 0 0.8rem;
  display: inline-flex;
  align-items: center;
}
collab-nav-3-menu .container .content .tabs li:not(.icon-back-button) svg {
  width: 12px;
  height: 12px;
}
collab-nav-3-menu .container .content .tabs li:not(.icon-back-button) .icon-error {
  margin-left: 0.3rem;
  color: red;
}
collab-nav-3-menu .container .content .tabs li:not(.icon-back-button) .tab-title {
  margin-left: 0.4rem;
}
collab-nav-3-menu .container .content .tabs li:not(.icon-back-button) span {
  font-size: 14px;
}
collab-nav-3-menu .container .content .tabs li:not(.icon-back-button).active {
  color: var(--collab-nav-3-link-active);
}
collab-nav-3-menu .container .content .tabs li:not(.icon-back-button).iconclose .tab-title {
  display: none;
}
collab-nav-3-menu .container .content .tabs li:not(.icon-back-button).has-error span {
  color: red;
}
collab-nav-3-menu .container .content .tabs.full li.iconclose .tab-title {
  display: inline;
}
collab-nav-3-menu .container .content .title.menu-hidden,
collab-nav-3-menu .container .content .tools.menu-hidden,
collab-nav-3-menu .container .content .tabs.menu-hidden {
  display: none;
}
`);
        this.msize = '';
        this.msizeHeight = '';
        this.isMls2 = '';
        this._menuChecked = false;
        this._lastMode = 'initial';
        this._activeTitle = { text: '', icon: '' };
        this._tabSelected = 0;
        this._historyTabs = [];
        this._resizeTimeout = 0;
        this._hiddenEls = new Set();
        this.msg = messages['en'];
        this._menu = {
            title: 'Example',
            main: {},
            tools: {
                darkLight: {
                    type: 'cycle',
                    selected: 0,
                    options: [
                        { text: 'Light', icon: 'f185' },
                        { text: 'Dark', icon: 'f186' },
                    ]
                },
                languages: {
                    type: 'dropdown',
                    selected: 0,
                    options: []
                },
                watchPreview: {
                    type: 'cycle',
                    selected: 0,
                    options: [
                        { text: 'Run', icon: 'f04c' },
                        { text: 'Pause', icon: 'f04b' },
                    ]
                },
            },
            tabs: {
                group: 'Mode',
                type: 'full',
                selected: 0,
                options: [
                    { text: 'Desktop', icon: 'f390' },
                    { text: 'Mobile', icon: 'f3cf' },
                ]
            }
        };
        this._isInternalAboutLastOpened = false;
        this._lastTitle = '';
        this._onHamburgerChange = (e) => {
            this._menuChecked = e.target.checked;
            if (!this._menuChecked) {
                this._actionPage = undefined;
                this._lastMode = 'initial';
                if (this._isInternalAboutLastOpened) {
                    this._setMenuTitle(this._lastTitle);
                    this._isInternalAboutLastOpened = false;
                    this._lastTitle = '';
                }
                const menu = this._getMenuOptions();
                if (menu) {
                    this._activeTitle = { ...(typeof menu.title === 'string' ? { text: menu.title, icon: '' } : menu.title) };
                    if (menu.onClickMain && menu.mainDefault && !this._menuChecked)
                        menu.onClickMain(menu.mainDefault);
                    if (menu.tabs !== undefined)
                        this._selectTab(menu.tabs.selected ?? 0);
                }
            }
            this._layoutNav3();
        };
        this._onBackClick = () => {
            if (this._historyTabs.length > 1) {
                const actual = this._historyTabs.pop();
                const prev = this._historyTabs[this._historyTabs.length - 1];
                this._tabSelected = prev.index;
                const menu = this._getMenuOptions();
                if (menu?.tabs)
                    menu.tabs.selected = prev.index;
                const onNav = menu?.onClickTabsNavigation;
                if (onNav && actual)
                    onNav(prev.index, actual.element, prev.element);
            }
        };
        this._onTitleClick = () => {
            const menu = this._getMenuOptions();
            if (menu?.onClickTitle)
                menu.onClickTitle(this._activeTitle.text);
        };
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        this.setAttribute('mheight', '40');
        this._initMenu();
    }
    updated(changed) {
        if (changed.has('msize')) {
            const [width] = this.msize.split(',');
            const ul = this.querySelector('.menu-list');
            if (ul)
                ul.style.width = width + 'px';
            const container = this.querySelector('.container');
            if (container)
                container.classList.toggle('hidden', width === '0');
            if (this._resizeTimeout)
                clearTimeout(this._resizeTimeout);
            this._resizeTimeout = window.setTimeout(() => this._onResizeWidthChange((+width) - 38), 200);
        }
        if (changed.has('msizeHeight')) {
            const ul = this.querySelector('.menu-list');
            if (ul)
                ul.style.maxHeight = this.msizeHeight + 'px';
        }
        this._registerTooltips();
    }
    render() {
        this.msg = messages[this.getMessageKey(messages)] || messages['en'];
        const menu = this._getMenuOptions();
        if (!menu)
            return nothing;
        return html `
            <div>
                <div class=${classMap({ container: true, checked: this._menuChecked })}>
                    <label class="menu">
                        <input class="menu-btn" type="checkbox" .checked=${this._menuChecked}
                               @change=${this._onHamburgerChange}>
                        <span class="menu-icon"></span>
                    </label>
                    <div class="content">
                        <ul class=${classMap({ tabs: true, full: menu.tabs?.type === 'full', compact: menu.tabs?.mode === 'compact', 'menu-hidden': this._hiddenEls.has('tabs') })}>
                            ${menu.tabs?.mode === 'compact' ? html `
                                <li class=${classMap({ 'icon-back-button': true, 'back-button-hidden': this._historyTabs.length < 2 })}
                                    @click=${this._onBackClick}>
                                    ${this._iconTpl('f053', '')}
                                </li>
                            ` : nothing}
                            ${(menu.tabs?.options || []).map((item, index) => html `
                                <li data-key="${index}" data-tooltip="${item.text}"
                                    class=${classMap({ active: this._tabSelected === index, iconclose: this._tabSelected !== index })}
                                    @click=${(e) => { e.preventDefault(); this._onTabClick(index); }}>
                                    ${this._iconTpl(item.icon, item.class)}
                                    <span class="tab-title">${item.text}</span>
                                </li>
                            `)}
                        </ul>
                        <div class=${classMap({ title: true, 'menu-hidden': this._hiddenEls.has('title') })}
                             @click=${this._onTitleClick}>
                            ${this._activeTitle.icon ? html `<i class=${this._faClass(this._activeTitle.icon)}>${unsafeHTML('&#x' + this._activeTitle.icon)}</i>` : nothing}
                            ${menu.onClickTitle ? html `<div>${this._activeTitle.text}</div>` : html `<span>${this._activeTitle.text}</span>`}
                        </div>
                        <div class=${classMap({ tools: true, 'menu-hidden': this._hiddenEls.has('tools') })}>
                            ${this._renderTools(menu, false)}
                        </div>
                    </div>
                </div>
                <ul class="menu-list" style="display:${this._menuChecked ? '' : 'none'}">
                    ${this._menuChecked ? this._renderMenuList(menu) : nothing}
                </ul>
                <div class="collab-nav-3-menu-action" style="display:${this._actionPage ? 'block' : 'none'}">
                    ${this._actionPage ? html `${this._actionPage}` : nothing}
                </div>
            </div>
        `;
    }
    _renderTools(menu, onlyMenuMode) {
        const tools = menu.tools || {};
        return Object.entries(tools).map(([key, tool]) => {
            if (onlyMenuMode && !tool['onlyMenu'])
                return nothing;
            if (!onlyMenuMode && tool['onlyMenu'])
                return nothing;
            return this._renderTool(key, tool, onlyMenuMode ? 'menu' : '');
        });
    }
    _renderTool(key, tool, renderType) {
        const onClickTools = this._getMenuOptions()?.onClickTools;
        if (tool.type === 'link')
            return html `
            <collab-nav-3-menu-tools-link key="${key}" rendertype="${renderType}"
                .tool=${tool} .onClickTools=${onClickTools}></collab-nav-3-menu-tools-link>`;
        if (tool.type === 'cycle')
            return html `
            <collab-nav-3-menu-tools-cycle key="${key}" rendertype="${renderType}"
                selected="${tool.selected || 0}"
                .tool=${tool} .onClickTools=${onClickTools}></collab-nav-3-menu-tools-cycle>`;
        if (tool.type === 'dropdown')
            return html `
            <collab-nav-3-menu-tools-dropdown key="${key}" rendertype="${renderType}"
                selected="${tool.selected || 0}"
                icon="${tool.icon || ''}"
                .tool=${tool} .onClickTools=${onClickTools}></collab-nav-3-menu-tools-dropdown>`;
        if (tool.type === 'tree-dropdown')
            return html `
            <collab-nav-3-menu-tools-tree-dropdown key="${key}" rendertype="${renderType}"
                selected="${(tool.selected || []).toString()}"
                icon="${tool.icon || ''}"
                .tool=${tool} .onClickTools=${onClickTools}></collab-nav-3-menu-tools-tree-dropdown>`;
        return nothing;
    }
    _renderMenuList(menu) {
        const onClickMain = menu.onClickMain;
        const main = menu.main || {};
        const tools = menu.tools || {};
        const tabs = menu.tabs;
        if (!tabs)
            return html `${nothing}`;
        return html `
            ${Object.entries(main).map(([key, data]) => html `
                <li>
                    <div @click=${(e) => { e.preventDefault(); if (typeof onClickMain === 'function')
            onClickMain(key); }}>
                        ${typeof data === 'string' ? data : html `
                            ${this._iconTpl(data.icon, data.class, 'icon-menu-list')}
                            <span>${data.text}</span>
                        `}
                    </div>
                </li>
            `)}
            ${this.isMls2 === 'true' ? html `
                <li><div @click=${() => this._showAbout()}>${this.msg.about}</div></li>
            ` : nothing}
            ${Object.keys(tools).length > 0 ? html `<li><hr></li>` : nothing}
            ${Object.entries(tools).map(([key, tool]) => html `
                <li><div>${this._renderTool(key, tool, 'menu')}</div></li>
            `)}
            ${tabs?.options?.length || 0 > 0 ? html `
                <li><hr></li>
                <li class=${classMap({ 'with-drop': true })}>
                    <div @click=${(e) => { e.preventDefault(); e.currentTarget.closest('li')?.classList.toggle('opened'); }}>
                        ${tabs.group || ''}: ${tabs.options[tabs.selected || 0]?.text}
                        <ul class="sub-menu">
                            ${tabs.options.map((item, index) => html `
                                <li data-key="${index}">
                                    <div @click=${(e) => { e.preventDefault(); this._onTabFromMenu(index); }}>
                                        ${this._iconTpl(item.icon, item.class)}
                                        <span class="title">${item.text}</span>
                                    </div>
                                </li>
                            `)}
                        </ul>
                    </div>
                </li>
            ` : nothing}
        `;
    }
    _onTabClick(index) {
        this._selectTab(index);
        const menu = this._getMenuOptions();
        if (menu?.onClickTabs)
            menu.onClickTabs(index);
    }
    _onTabFromMenu(index) {
        this._menuChecked = false;
        this._selectTab(index);
        const menu = this._getMenuOptions();
        if (menu?.onClickTabs)
            menu.onClickTabs(index);
    }
    _selectTab(index) {
        this._tabSelected = index;
        const menu = this._getMenuOptions();
        if (menu?.tabs)
            menu.tabs.selected = index;
    }
    _initMenu() {
        const menu = this._getMenuOptions();
        if (!menu)
            return;
        menu.setMode = this.setMode.bind(this);
        menu.updateTitle = this._updateTitle.bind(this);
        menu.getLastMode = () => this._lastMode;
        menu.setTabActive = this._setTabActive.bind(this);
        menu.tabNavigate = this._tabNavigateNext.bind(this);
        menu.tabBack = this._onBackClick;
        menu.toggleErrorTab = this._toggleErrorTab.bind(this);
        menu.setMenuActive = this._openMenuMainItem.bind(this);
        menu.selectTool = this._selectButton.bind(this);
        menu.closeMenu = this._closeMenu.bind(this);
        menu.refresh = this._refresh.bind(this);
        if (menu.tabs?.selected !== undefined)
            this._tabSelected = menu.tabs.selected;
    }
    setMode(mode, page) {
        if (!mode)
            mode = this._lastMode;
        this._lastMode = mode;
        if (mode === 'initial') {
            this._menuChecked = false;
            const menu = this._getMenuOptions();
            if (menu)
                this._activeTitle = { ...(typeof menu.title === 'string' ? { text: menu.title, icon: '' } : menu.title) };
        }
        else if (mode === 'editor') {
            this._menuChecked = true;
        }
        else if (mode === 'page') {
            this._actionPage = page;
            this._menuChecked = true;
        }
    }
    _updateTitle() {
        const menu = this._getMenuOptions();
        if (!menu)
            return;
        const t = typeof menu.title === 'string' ? { text: menu.title, icon: '' } : menu.title;
        this._activeTitle = { ...t };
    }
    _setTabActive(index) { this._selectTab(index); }
    _tabNavigateNext(index, oldTab, newTab) {
        this._selectTab(index);
        this._historyTabs = [...this._historyTabs, { index, element: newTab }];
        const menu = this._getMenuOptions();
        if (menu?.tabs)
            menu.tabs.previous = index;
        if (menu?.onClickTabsNavigation)
            menu.onClickTabsNavigation(index, oldTab, newTab);
    }
    _toggleErrorTab(op, show) {
        const li = this.querySelector(`ul.tabs li[data-key="${op}"]`);
        if (!li)
            return;
        li.querySelector('.icon-error')?.remove();
        li.classList.toggle('has-error', show);
        if (show) {
            const err = document.createElement('span');
            err.className = 'icon-error fa';
            err.innerHTML = '&#x21';
            li.appendChild(err);
        }
    }
    _openMenuMainItem(option) {
        this._menuChecked = true;
        const menu = this._getMenuOptions();
        if (menu?.onClickMain)
            menu.onClickMain(option);
    }
    _selectButton(op) {
        const tools = this.querySelector('.tools');
        const btn = tools?.querySelector(`span[data-key="${op}"]`);
        if (btn)
            btn.click();
    }
    _closeMenu() { this._menuChecked = false; }
    _refresh(mode = 'full') { this.requestUpdate(); }
    _showAbout() {
        const menu = this._getMenuOptions();
        this._lastTitle = menu ? typeof menu.title === 'string' ? menu.title : menu.title.text : '';
        this._isInternalAboutLastOpened = true;
        const toolbarContentEl = this.closest('collab-nav-3-service');
        const toolbarEl = this.closest('collab-nav-3');
        const serviceName = toolbarContentEl?.getAttribute('data-service') || 'Is Preview';
        const serviceLevel = toolbarEl?.getAttribute('level') || 'Is Preview';
        const servicePosition = toolbarEl?.getAttribute('toolbarposition') || 'Is Preview';
        this._setMenuTitle(`${this.msg.about} ${serviceName}`);
        this._updateTitle();
        const div = document.createElement('div');
        div.innerHTML = `<h3>${this.msg.aboutThisService}</h3><ul><li>${this.msg.reference}: ${serviceName}</li><li>${this.msg.level}: ${serviceLevel}</li><li>${this.msg.position}: ${servicePosition}</li></ul>`;
        this.setMode('page', div);
        return true;
    }
    _setMenuTitle(title) {
        const menu = this._getMenuOptions();
        if (!menu)
            return;
        if (typeof menu.title === 'string')
            menu.title = title;
        else
            menu.title.text = title;
    }
    _layoutNav3() {
        const nav3 = this.closest('collab-nav-3');
        if (nav3?.layout)
            nav3.layout();
    }
    _getMenuOptions() {
        if (this._menu)
            return this._menu;
        const parent = this.parentElement;
        if (!parent)
            return this._defaultMenu();
        const widget = parent['mlsWidget'];
        if (!widget)
            return this._defaultMenu();
        const menu = widget['menu'];
        if (!menu || typeof menu !== 'object')
            return this._defaultMenu();
        if (typeof menu.title === 'string')
            menu.title = { text: menu.title, icon: '' };
        this._activeTitle = { ...menu.title };
        this._menu = menu;
        return menu;
    }
    _defaultMenu() {
        if (this._menu)
            return this._menu;
        const menu = {
            title: { text: this.msg.preview, icon: '' },
            main: {},
            tabs: undefined,
            tools: {},
            mainDefault: '',
            lastMain: '',
            onClickMain: undefined, onClickTabs: undefined, onClickTitle: undefined, onClickTools: undefined,
            onClickTabsNavigation: undefined, setMode: undefined, closeMenu: undefined, getLastMode: undefined,
            refresh: undefined, selectTool: undefined, setMenuActive: undefined, setTabActive: undefined,
            tabNavigate: undefined, tabBack: undefined, toggleErrorTab: undefined, updateTitle: undefined,
        };
        this._activeTitle = { text: 'Preview', icon: '' };
        this._menu = menu;
        return menu;
    }
    _registerTooltips() {
        const tooltipEl = document.querySelector('collab-tooltip');
        if (!tooltipEl?.tooltip)
            return;
        this.querySelectorAll('li[data-tooltip]').forEach(el => tooltipEl.tooltip(el));
    }
    _onResizeWidthChange(newWidth) {
        const content = this.querySelector('.content');
        if (!content)
            return;
        const totalWidth = content.getBoundingClientRect().width;
        const tabs = this.querySelector('.tabs');
        const tools = this.querySelector('.tools');
        const title = this.querySelector('.title');
        const tabsW = (tabs?.getBoundingClientRect().width || 0) + 10;
        const toolsW = tools?.getBoundingClientRect().width || 0;
        const titleW = title?.getBoundingClientRect().width || 0;
        const margin = 15;
        const total = totalWidth + margin;
        const next = new Set(this._hiddenEls);
        if (total > newWidth) {
            if ((total - titleW) < newWidth)
                next.add('title');
            else if ((total - titleW - toolsW) < newWidth) {
                next.add('title');
                next.add('tools');
            }
            else if ((total - titleW - toolsW - tabsW) < newWidth) {
                next.add('title');
                next.add('tools');
                next.add('tabs');
            }
        }
        else if (total < newWidth) {
            if (newWidth >= tabsW && next.has('tabs'))
                next.delete('tabs');
            if (newWidth >= (toolsW + tabsW) && !next.has('tabs') && next.has('tools'))
                next.delete('tools');
            if (newWidth >= (toolsW + tabsW + titleW + margin) && next.has('title') && !next.has('tabs') && !next.has('tools')) {
                next.delete('title');
                next.delete('tools');
                next.delete('tabs');
            }
        }
        this._hiddenEls = next;
    }
    _iconTpl(str, className, extraClass = '') {
        const cls = [className || '', extraClass].filter(Boolean).join(' ');
        if (!str)
            return html `<i class="${cls}"></i>`;
        if (str.trim().startsWith('<svg'))
            return html `<span class="${cls}">${unsafeHTML(str)}</span>`;
        return html `<i class="${this._faClass(str)} ${cls}">${unsafeHTML('&#x' + str)}</i>`;
    }
    _faClass(unicode) {
        const brands = new Set(['f38b', 'f09a', 'f099', 'f0d5', 'f1a1', 'f17e', 'f1e3', 'f16a', 'f13b']);
        if (unicode?.startsWith('f') && unicode.length === 4 && brands.has(unicode))
            return 'fa-brands';
        return 'fa';
    }
};
__decorate([
    property({ attribute: 'msize' })
], CollabNav3Menu.prototype, "msize", void 0);
__decorate([
    property({ attribute: 'msize-height' })
], CollabNav3Menu.prototype, "msizeHeight", void 0);
__decorate([
    property({ attribute: 'is-mls2' })
], CollabNav3Menu.prototype, "isMls2", void 0);
__decorate([
    state()
], CollabNav3Menu.prototype, "_menuChecked", void 0);
__decorate([
    state()
], CollabNav3Menu.prototype, "_lastMode", void 0);
__decorate([
    state()
], CollabNav3Menu.prototype, "_activeTitle", void 0);
__decorate([
    state()
], CollabNav3Menu.prototype, "_actionPage", void 0);
__decorate([
    state()
], CollabNav3Menu.prototype, "_tabSelected", void 0);
__decorate([
    state()
], CollabNav3Menu.prototype, "_historyTabs", void 0);
__decorate([
    state()
], CollabNav3Menu.prototype, "_hiddenEls", void 0);
CollabNav3Menu = __decorate([
    customElement('collab-nav-3-menu')
], CollabNav3Menu);
export { CollabNav3Menu };
