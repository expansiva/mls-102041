/// <mls fileReference="_102041_/l2/collab-loading.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
let CollabLoading = class CollabLoading extends StateLitElement {
    render() {
        return html `
            <div class="loading">
                <span>Loading...</span>
            </div>
        `;
    }
};
CollabLoading = __decorate([
    customElement('collab-loading')
], CollabLoading);
export { CollabLoading };
