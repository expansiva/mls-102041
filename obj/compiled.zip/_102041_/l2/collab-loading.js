/// <mls fileReference="_102041_/l2/collab-loading.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let CollabLoading = class CollabLoading extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-loading.toolbar-loading .loading {
  top: 0px;
  background: linear-gradient(180deg, var(--collab-nav-bg-3) 0%, var(--collab-nav-bg-2) 63%);
}
collab-loading .loading {
  position: absolute;
  background-color: var(--collab-nav-bg-2);
  color: var(--collab-nav-color);
  z-index: 9999;
  top: 30px;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}
collab-loading .loading span {
  font-size: 24px;
  font-weight: bold;
  animation: pulse 2s ease-in-out infinite;
  max-width: 100%;
  white-space: normal;
  word-break: break-word;
  padding: 1rem;
}
@keyframes pulse {
  0% {
    opacity: 0.75;
  }
  50% {
    opacity: 1;
  }
  100% {
    opacity: 0.75;
  }
}
`);
    }
    render() {
        return html `
            <div class="loading">
                <span>Loading...</span>
            </div>
        `;
    }
};
CollabLoading = __decorate([
    customElement('collab-loading')
], CollabLoading);
export { CollabLoading };
