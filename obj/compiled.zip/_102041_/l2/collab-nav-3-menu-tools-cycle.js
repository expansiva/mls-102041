/// <mls fileReference="_102041_/l2/collab-nav-3-menu-tools-cycle.ts" enhancement="_102041_/l2/enhancementCollab.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_en = {
    actualState: 'Actual state',
    changeTo: 'Change to',
};
const message_pt = {
    actualState: 'Estado atual',
    changeTo: 'Alterar para',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let CollabNav3MenuToolsCycle = class CollabNav3MenuToolsCycle extends StateLitElement {
    constructor() {
        super(...arguments);
        this.key = '';
        this.selected = 0;
        this.renderType = '';
        this._menuOpened = false;
        this.msg = messages['en'];
        this._onToolClick = () => {
            if (!this.tool)
                return;
            const nextIndex = (this.selected + 1) % this.tool.options.length;
            this.selected = nextIndex;
            this.tool.selected = nextIndex;
            if (this._tooltipEl?.destroy)
                this._tooltipEl.destroy();
            if (typeof this.onClickTools !== 'function')
                throw new Error('onClickTools not found');
            this.onClickTools(this.key);
        };
        this._onMenuHeaderClick = (e) => {
            this._menuOpened = !this._menuOpened;
        };
    }
    get _tooltipEl() { return document.querySelector('collab-tooltip'); }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.renderType === 'menu') {
            this.classList.add('list');
            this._syncFromToolbar();
        }
    }
    updated() {
        const span = this.querySelector('span[data-tooltip]');
        if (this._tooltipEl?.tooltip && span)
            this._tooltipEl.tooltip(span);
    }
    render() {
        this.msg = messages[this.getMessageKey(messages)] || messages['en'];
        if (!this.tool)
            return nothing;
        return this.renderType === 'menu' ? this._renderAsMenu() : this._renderAsTool();
    }
    _renderAsTool() {
        const option = this.tool?.options[this.selected];
        if (!option)
            return nothing;
        return html `
            <span data-key="${this.key}" data-tooltip="${option.text}" @click=${this._onToolClick}>
                ${this._iconTpl(option.icon, option.class)}
            </span>
        `;
    }
    _renderAsMenu() {
        const option = this.tool?.options[this.selected];
        if (!option)
            return nothing;
        return html `
            <div data-key="${this.key}"
                 class=${classMap({ opened: this._menuOpened })}
                 @click=${this._onMenuHeaderClick}>
                <div class="cycle-list-header">
                    ${this._iconTpl(option.icon, option.class)}
                    <span>${this.key.charAt(0).toUpperCase() + this.key.slice(1).toLowerCase()}</span>
                    <span>: ${option.text}</span>
                </div>
                <ul class="sub-menu">
                    ${this.tool?.options.map((opt, index) => html `
                        <li class=${classMap({ selected: index === this.selected })}
                            @click=${(e) => { e.stopPropagation(); this._onMenuItemClick(index); }}>
                            <div>
                                ${this._iconTpl(opt.icon, opt.class)}
                                <span>${index === this.selected ? this.msg.actualState + ': ' + opt.text : this.msg.changeTo + ': ' + opt.text}</span>
                            </div>
                        </li>
                    `)}
                </ul>
            </div>
        `;
    }
    _onMenuItemClick(index) {
        if (!this.tool)
            return;
        const similar = this._findToolbarCounterpart();
        if (similar)
            similar.setAttribute('selected', index.toString());
        this.selected = index;
        this._menuOpened = false;
        this.tool.selected = index;
        if (typeof this.onClickTools !== 'function')
            throw new Error('onClickTools not found');
        this.onClickTools(this.key);
    }
    _syncFromToolbar() {
        const similar = this._findToolbarCounterpart();
        if (similar) {
            const sel = similar.getAttribute('selected');
            if (sel)
                this.selected = +sel;
        }
    }
    _findToolbarCounterpart() {
        return this.closest('collab-nav-3-menu')
            ?.querySelector('.tools')
            ?.querySelector(`collab-nav-3-menu-tools-cycle[key="${this.key}"]`);
    }
    _iconTpl(str, className) {
        const cls = className || '';
        if (!str)
            return html `<i class="${cls}"></i>`;
        if (str.trim().startsWith('<svg'))
            return html `<span class="${cls}">${unsafeHTML(str)}</span>`;
        return html `<i class="fa ${cls}">${unsafeHTML('&#x' + str)}</i>`;
    }
};
__decorate([
    property({ attribute: 'key' })
], CollabNav3MenuToolsCycle.prototype, "key", void 0);
__decorate([
    property({ type: Number, attribute: 'selected' })
], CollabNav3MenuToolsCycle.prototype, "selected", void 0);
__decorate([
    property({ attribute: 'rendertype' })
], CollabNav3MenuToolsCycle.prototype, "renderType", void 0);
__decorate([
    state()
], CollabNav3MenuToolsCycle.prototype, "_menuOpened", void 0);
CollabNav3MenuToolsCycle = __decorate([
    customElement('collab-nav-3-menu-tools-cycle')
], CollabNav3MenuToolsCycle);
export { CollabNav3MenuToolsCycle };
