/// <mls fileReference="_102041_/l2/buildProject.ts" enhancement="_blank"/>
import { getPath } from '/_102027_/l2/utils.js';
import { convertFileToTag, resolveTagToFile } from '/_102041_/l2/utils.js';
import { getGlobalCss } from '/_102027_/l2/designSystemBase.js';
export function buildIndex(language) {
    const index = mls.stor.files['102041_2_index.html'];
    if (!index)
        throw new Error('No find index page');
    return buildLandingPageByStor(index, language);
}
export async function buildLandingPageByStor(stor, language, theme = 'Default') {
    const contentHTML = await stor.getContent();
    let json = await getDependenciesByHtmlFile(stor, contentHTML);
    // const js = await buildJs(json, stor);
    return json;
}
async function buildJs(json, stor) {
    await loadEsbuild();
    let allImports = [...new Set(json.importsJs.filter((i) => i.startsWith('/')))];
    const virtualFsPlugin = {
        name: 'virtual-fs',
        setup(build) {
            build.onResolve({ filter: /.*/ }, (args) => {
                if ((args.path.startsWith("/") || args.path.startsWith("./") || args.path.startsWith("../")) &&
                    !args.importer.startsWith("https://")) {
                    const url = new URL(args.path, 'file:' + args.importer);
                    let path = url.pathname;
                    if (!(/_(\d+)_/.test(path))) {
                        const info = getPath(args.importer.replace('/l2/', '').replace('/', ''));
                        if (!info)
                            throw new Error('[virtualFsPlugin] Not found path:' + args.importer.replace('/l2/', '').replace('/', ''));
                        if (!info.project)
                            info.project = mls.actualProject;
                        if (path.indexOf(`_${info.project}_`) < 0) {
                            path = url.pathname.replace('/', `/_${info.project}_`);
                        }
                    }
                    return { path, namespace: 'virtual' };
                }
                return null;
            });
            build.onLoad({ filter: /.*/, namespace: 'virtual' }, async (args) => {
                try {
                    let path = args.path;
                    const res = await fetch(path);
                    if (!res.ok)
                        throw new Error(`Error get ${args.path}`);
                    const text = await res.text();
                    return { contents: text, loader: 'js' };
                }
                catch (e) {
                    console.info('erro:' + args.path);
                    return {
                        contents: '',
                        loader: 'js',
                        warnings: [{
                                text: e.message, notes: [
                                    { text: 'build-error' }
                                ]
                            }]
                    };
                }
            });
        },
    };
    const virtualEntryPath = "virtual-entry.js";
    const virtualEntryContent = allImports.map(path => `import "${path}";`).join("\n");
    const result = await esbuild.build({
        stdin: {
            contents: virtualEntryContent,
            resolveDir: "/",
            sourcefile: virtualEntryPath,
            loader: "js"
        },
        bundle: true,
        minify: false,
        format: "esm",
        sourcemap: false,
        write: false,
        plugins: [virtualFsPlugin]
    });
    return result.outputFiles[0].text;
}
async function getDependenciesByHtmlFile(file, html) {
    const { project, shortName, folder } = file;
    const myImportsMap = [];
    const myImports = [];
    const myLinks = [];
    const myErrors = [];
    const myModules = {};
    let tags = extractTagsCustom(html);
    const tag = convertFileToTag({ project, shortName, folder });
    if (!tags.includes(tag))
        tags.push(tag);
    await loadMyNeedsToCompile(tags, myImportsMap, myImports, myLinks, myErrors, myModules);
    let globalCss = await getGlobalCss(project, 'Default');
    return {
        importsMap: myImportsMap,
        importsJs: Array.from(new Set(myImports)),
        importsLinks: Array.from(new Map(myLinks.map(item => [item.ref, item])).values()),
        globalCss,
        tokens: '',
        errors: myErrors
    };
}
function extractTagsCustom(html) {
    const container = document.createElement('div');
    container.innerHTML = html;
    const customTags = new Set();
    const allElements = container.querySelectorAll('*');
    allElements.forEach(element => {
        const tagName = element.tagName.toLowerCase();
        const isCustomTag = tagName.includes('-');
        const isInCodeBlock = element.closest('code') !== null;
        if (isCustomTag &&
            !isInCodeBlock) {
            customTags.add(tagName);
        }
    });
    return Array.from(customTags);
}
async function loadMyNeedsToCompile(tags, myImportsMap, myImports, myLinks, myErrors, myModules) {
    try {
        if (tags.length <= 0)
            return;
        const info = resolveTagToFile(tags[0]);
        if (!info)
            return;
        const lv = mls.actualLevel === 1 ? 1 : 2;
        const key = mls.stor.getKeyToFiles(info.project, lv, info.shortName, info.folder, '.ts');
        const f = mls.stor.files[key];
        const { project, shortName, folder } = info;
        if (!project || !shortName)
            return;
        const ipath = { project, shortName: shortName, folder: f ? f.folder : folder };
        const enhacementName = await getEnhancementFromFetch(ipath);
        if (!enhacementName)
            throw new Error('enhacementName not valid');
        if (enhacementName === '_blank') {
            await getJSBlank(myImports, ipath);
            return;
        }
        if (!myModules[enhacementName]) {
            const info = getPath(enhacementName);
            if (!info)
                throw new Error('[] Not found path:' + enhacementName);
            const mModule = await mls.l2.enhancement.getEnhancementModule(info);
            myModules[enhacementName] = {
                jsMap: false,
                mModule
            };
        }
        await getJSImporMap(myImportsMap, enhacementName, myModules);
        await getJSImportEnhancement(myImports, enhacementName, myModules);
        await getJS(myImports, enhacementName, ipath, myModules);
        await getLinks(myLinks, enhacementName, ipath, myModules);
    }
    catch (e) {
        if (tags.length <= 0)
            return;
        myErrors.push({ tag: tags[0], error: e.message });
    }
    finally {
        tags.shift();
        if (tags.length > 0) {
            await loadMyNeedsToCompile(tags, myImportsMap, myImports, myLinks, myErrors, myModules);
        }
    }
}
async function getEnhancementFromFetch(file) {
    const url = getImportUrl(file);
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Failed to fetch ${url}: ${response.status} ${response.statusText}`);
    }
    const txt = await response.text();
    const lines = txt.replace(/\r\n/g, '\n').split('\n');
    const mlsLine = lines.find(line => line.trim().startsWith('/// <mls '));
    ;
    if (!mlsLine) {
        throw new Error(`Not found tag 'mls' in ${url}`);
    }
    const enhancementMatch = mlsLine.match(/enhancement="([^"]+)"/);
    if (!enhancementMatch) {
        throw new Error('Not found attr "enhancement" in ' + url);
    }
    return enhancementMatch[1];
}
function getImportUrl(info) {
    let url = `/_${info.project}_/l2/${info.shortName}`;
    if (info.folder) {
        url = `/_${info.project}_/l2/${info.folder}/${info.shortName}`;
    }
    return url;
}
async function getJSImportEnhancement(myImports, enhacementName, myModules) {
    if (!myModules[enhacementName])
        throw new Error('Enhacement not found ');
    const mmodule = myModules[enhacementName].mModule;
    if (!mmodule || !mmodule.requires)
        return;
    const aRequire = mmodule.requires;
    aRequire.forEach((i) => {
        if (i.type !== 'import')
            return;
        myImports.push(i.ref);
    });
}
async function getJSImporMap(myImportsMap, enhacementName, myModules) {
    if (!myModules[enhacementName])
        throw new Error('Enhacement not found ');
    if (myModules[enhacementName].jsMap)
        return;
    myModules[enhacementName].jsMap = true;
    const mmodule = myModules[enhacementName].mModule;
    if (!mmodule || !mmodule.requires)
        return;
    const aRequire = mmodule.requires;
    aRequire.forEach((i) => {
        if (i.type !== 'cdn')
            return;
        myImportsMap.push(`"${i.name}": "${i.ref}"`);
    });
}
async function getJSBlank(myImports, mfile) {
    let key = getImportUrl(mfile);
    if (myImports.includes(key))
        return;
    myImports.push(key);
}
async function getJS(myImports, enhacementName, mfile, myModules) {
    if (!myModules[enhacementName])
        throw new Error('Enhacement not found ');
    let key = getImportUrl(mfile);
    if (myImports.includes(key))
        return;
    myImports.push(key);
}
async function getLinks(myLinks, enhacementName, mfile, myModules) {
    if (!myModules[enhacementName])
        throw new Error('Enhacement not found ');
    const mmodule = myModules[enhacementName].mModule;
    if (!mmodule || !mmodule.requires)
        return;
    const aRequire = mmodule.requires;
    aRequire.forEach((i) => {
        if (i.type !== 'link')
            return;
        myLinks.push({ rel: i.args, ref: i.ref });
    });
}
var esbuild;
async function loadEsbuild() {
    if (mls.esbuild) {
        esbuild = mls.esbuild;
    }
    else if (!mls.esbuildInLoad)
        await initializeEsBuild();
}
async function initializeEsBuild() {
    mls.esbuildInLoad = true;
    const url = 'https://unpkg.com/esbuild-wasm@0.14.54/esm/browser.min.js';
    if (!esbuild) {
        esbuild = await import(url);
        await esbuild.initialize({
            wasmURL: "https://unpkg.com/esbuild-wasm@0.14.54/esbuild.wasm"
        });
        mls.esbuild = esbuild;
        mls.esbuildInLoad = false;
    }
}
