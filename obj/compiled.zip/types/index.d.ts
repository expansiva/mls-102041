declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/propiertiesLit" {
    export function getPropierties(model: mls.editor.IModelTS): mls.l2.enhancement.IProperties[];
    export interface IMember {
        name: string;
        pos: number;
        type: string;
        comment: string;
        modifiers: string[];
        tags: ITag[];
        parameters?: IParameter[];
        initializerText: string;
        initializerType: string;
    }
    export interface ITag {
        name: string;
        pos: number;
        tagName: string;
        comment: string;
    }
    export interface IParameter {
        name: string;
        comment: string;
        type: string;
        modifiers: string[];
    }
    export interface IJSDoc {
        name: string;
        pos: number;
        type: string;
        comment: string;
        members: IMember[];
        tags: ITag[];
    }
    export interface IDecoratorClassInfo {
        decoratorName: string;
        tagName: string;
    }
    export interface IDecoratorItem {
        line: number;
        character: number;
        text: string;
    }
    export interface IDecoratorDetails {
        parentName: string;
        type: string;
        pos: number;
        decorators: IDecoratorItem[];
    }
    export interface IDecoratorDictionary {
        [key: number]: IDecoratorDetails;
    }
}
declare module "_102041_/l2/utils" {
    export interface IFileInfoBase {
        project: number;
        level: number;
        shortName: string;
        folder: string;
        extension: string;
    }
    export interface IResolvedFile {
        project: number;
        shortName: string;
        folder: string;
    }
    export function resolveTagToFile(tag: string): IResolvedFile | undefined;
    export function convertFileToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function isPageFile(folder: string): boolean;
    export function validateTagName(modelTS: mls.editor.IModelTS): boolean;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102041_/l2/buildProject" {
    export function buildIndex(language: string): Promise<string>;
    export function buildLandingPageByStor(stor: mls.stor.IFileInfo, language: string, theme?: string): Promise<string>;
}
declare module "_102027_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102027_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102027_/l2/stateLitElement" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    import { PropertyValueMap } from 'lit';
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102041_/l2/collab-loading" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class CollabLoading extends StateLitElement {
        render(): any;
    }
}
declare module "_102041_/l2/collab-logo" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class CollabLogo extends StateLitElement {
        render(): any;
    }
}
declare module "_102041_/l2/collab-nav-1" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    interface IServicesByProjectConfig {
        services: string[];
    }
    interface INav1CollabServiceData {
        [key: number]: {
            left: any[];
            right: any[];
        };
    }
    export class CollabNav1 extends StateLitElement {
        tabindexactive: string;
        status: string;
        get tabActive(): number;
        get actualLevel(): number;
        get project(): number;
        private msg;
        private _currentLang;
        services: IServicesByProjectConfig;
        actualServices?: INav1CollabServiceData;
        reasons: {};
        private _items;
        private _statusMap;
        private _activeIndex;
        private _notificationCount;
        private _userAvatarSrc;
        private _userAdditional;
        private _lastActive;
        private _levelAlreadyReady;
        private _servicesDetailsArr;
        private _cacheInstancePromise;
        private _cacheKeysPromise;
        private readonly _staticService;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        addNotification(clear: boolean): void;
        changeIconToImage(tabIndex: number, src: string, additional?: {
            text: string;
            img?: string;
        }): void;
        forceInstanceIfNeed(arr: string[]): Promise<void>;
        updated(changed: Map<string, unknown>): void;
        render(): any;
        private _renderTab;
        private _renderNotification;
        private _renderUser;
        updated_tooltip(): void;
        private _onUserClick;
        private _setNotificationCount;
        private _openService;
        private _selectLevel;
        private _activeMe;
        private _fireChangeLevel;
        private _changeStatus;
        private _changeStatusIfAnonymous;
        private _checkIsAllLoaded;
        private _prepareServices;
        private _getUserServicesPreferences;
        private _mergeData;
        private _mergeData2;
        private _getDetailsServiceMls1;
        private _getDetailsServiceStaticMls1;
        private _getCacheInstance;
        private _getCacheKeys;
        private _getDetailsServiceCollabInJS3;
        private _getDetailsService2;
        private _prepareServicesByConfigProject;
        private _prepareJSONServiceData;
        private _parseJsonServicesByConfig;
        private _getShortcut;
        private _getShortcutLetter;
        private _defaultJson;
    }
}
declare module "_102041_/l2/collab-nav-2" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    type ICollabServicePosition = 'left' | 'right';
    type ICollabServiceState = 'foreground' | 'background';
    type ICollabServiceClass = 'separator-left' | 'separator-right';
    interface ICollabService3 {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
    }
    interface ICollabServiceData {
        [key: number]: {
            left: ICollabService3[];
            right: ICollabService3[];
        };
    }
    interface ICollabState {
        [key: number]: {
            left: string;
            right: string;
        };
    }
    export class CollabNav2 extends StateLitElement {
        level: number;
        status: string;
        get position(): ICollabServicePosition;
        actualServices?: ICollabServiceData;
        containerItens?: HTMLElement;
        private _services;
        private _controllersVisible;
        private _scrollLeft;
        private _scrollRight;
        private _badgesState;
        private _alreadyLoadedServices;
        private _onlyFirstTime;
        state_: ICollabState;
        private msg;
        private readonly _staticService;
        layout(): void;
        toogleBadge(show: boolean, path: string, saveState?: boolean): void;
        getUserServices(): Promise<ICollabServiceData>;
        addService(service: ICollabService3, level: number, position: ICollabServicePosition): Promise<void>;
        removeService(index: number, level: number, position: ICollabServicePosition): Promise<void>;
        moveService(fromIndex: number, toIndex: number, level: number, position: ICollabServicePosition): Promise<void>;
        updateClassName(index: number, newClass: ICollabServiceClass | undefined, level: number, position: ICollabServicePosition): Promise<void>;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(changed: Map<string, unknown>): Promise<void>;
        render(): any;
        private _renderItem;
        private _setEvents;
        private _onItemClick;
        private _selectItem;
        private _fireToolbarSelected;
        private _fireSelectedChangeNav3;
        private _onControllerClick;
        private _verifyControllers;
        private _checkControllersOnScroll;
        private _setShortCuts;
        private _renderServiceByLevel;
        private _renderAfterEnabled;
        private _onStatusChanged;
        private _setInitialServicesAfterEnabled;
        private _activeLastServiceClicked;
        private _getUserServices;
        private _getReasons;
        private _refreshOppositeNav2;
        private _staticServices;
    }
}
declare module "_102041_/l2/collab-nav-3-menu-tools-cycle" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    interface IOptionsToolsCycle {
        text: string;
        icon?: string;
        class?: string;
    }
    interface IToolsDataCycle {
        type: string;
        selected?: number;
        icon?: string;
        class?: string;
        options: IOptionsToolsCycle[];
    }
    export class CollabNav3MenuToolsCycle extends StateLitElement {
        key: string;
        selected: number;
        renderType: string;
        private _menuOpened;
        onClickTools?: Function;
        tool?: IToolsDataCycle;
        private msg;
        private get _tooltipEl();
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(): void;
        render(): any;
        private _renderAsTool;
        private _renderAsMenu;
        private _onToolClick;
        private _onMenuHeaderClick;
        private _onMenuItemClick;
        private _syncFromToolbar;
        private _findToolbarCounterpart;
        private _iconTpl;
    }
}
declare module "_102041_/l2/collab-nav-3-menu-tools-dropdown" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    interface IOptionsToolsDropDown {
        text: string;
        icon?: string;
        class?: string;
    }
    interface IToolsDataDropDown {
        type: string;
        selected?: number;
        icon?: string;
        class?: string;
        options: IOptionsToolsDropDown[];
    }
    export class CollabNav3MenuToolsDropdown extends StateLitElement {
        key: string;
        icon: string;
        selected: number;
        renderType: string;
        private _menuOpened;
        onClickTools?: Function;
        tool?: IToolsDataDropDown;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private _renderAsTool;
        private _renderAsMenu;
        private _getBtnMenu;
        private _onHostClick;
        private _onMenuHeaderClick;
        private _onOptionClick;
        private _onMenuItemClick;
        _closeDropdown(): void;
        private _onDocumentClick;
        private _onVisibilityChange;
        private _syncFromToolbar;
        private _findToolbarCounterpart;
        private _iconTpl;
    }
}
declare module "_102041_/l2/collab-nav-3-menu-tools-link" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    interface IOptionsToolsLink {
        text: string;
        icon?: string;
        class?: string;
    }
    interface IToolsLinkData {
        icon?: string;
        class?: string;
        options: IOptionsToolsLink[];
    }
    export class CollabNav3MenuToolsLink extends StateLitElement {
        key: string;
        renderType: string;
        onClickTools?: Function;
        tool?: IToolsLinkData;
        private get _tooltipEl();
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(): void;
        render(): any;
        private _renderAsTool;
        private _renderAsMenu;
        private _onToolClick;
        private _onMenuClick;
        private _iconTpl;
    }
}
declare module "_102041_/l2/collab-nav-3-menu-tools-tree-dropdown" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
    }
    interface IOptionsToolsTreeDropDown {
        text: string;
        icon?: string;
        class?: string;
        options: IOptionsSubMenu[];
    }
    interface IToolsDataTreeDropDown {
        type: string;
        selected?: number[];
        icon?: string;
        class?: string;
        options: IOptionsToolsTreeDropDown[];
    }
    export class CollabNav3MenuToolsTreeDropdown extends StateLitElement {
        key: string;
        icon: string;
        selected: string;
        renderType: string;
        private _dropOpen;
        private _menuOpened;
        private _openedItems;
        onClickTools?: Function;
        tool?: IToolsDataTreeDropDown;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private _renderAsTool;
        private _renderAsMenu;
        private _onHostClick;
        private _onMenuHeaderClick;
        private _toggleMenuItem;
        private _onLeafClick;
        private _onSubLeafClick;
        private _onMenuSubItemClick;
        _closeDropdown(): void;
        private _onDocumentClick;
        private _onVisibilityChange;
        private _iconTpl;
    }
}
declare module "_102041_/l2/collab-tooltip" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class CollabTooltip extends StateLitElement {
        private _timeoutId;
        private readonly _isMobile;
        private readonly _widthMarginOfError;
        render(): any;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        tooltip(el: HTMLElement): void;
        destroy: () => void;
        private _show;
    }
}
declare module "_102041_/l2/collab-nav-3-menu" {
    import "_102041_/l2/collab-nav-3-menu-tools-link";
    import "_102041_/l2/collab-tooltip";
    import "_102041_/l2/collab-nav-3-menu-tools-cycle";
    import "_102041_/l2/collab-nav-3-menu-tools-dropdown";
    import "_102041_/l2/collab-nav-3-menu-tools-tree-dropdown";
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    type TMode = 'initial' | 'page' | 'editor';
    interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    interface IOptionsSubMenu extends IOptions {
        options: IOptions[];
    }
    interface IToolsData1 {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
        icon?: string;
        class?: string;
    }
    interface IToolsData2 {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
        icon?: string;
        class?: string;
    }
    type IToolsData = IToolsData1 | IToolsData2;
    interface ITabs {
        type?: 'full' | 'onlyicon';
        effect?: string;
        mode?: 'normal' | 'compact';
        group?: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITools {
        [key: string]: IToolsData;
    }
    export interface IServiceMenu {
        title: IOptions | string;
        main?: IMain;
        tabs?: ITabs;
        tools?: ITools;
        mainDefault?: string;
        lastMain?: string;
        enabled?: boolean;
        onClickTitle?: Function;
        onClickMain?: Function;
        onClickTools?: Function;
        onClickTabs?: Function;
        onClickTabsNavigation?: Function;
        setMode?: Function;
        setTabActive?: Function;
        tabNavigate?: Function;
        tabBack?: Function;
        toggleErrorTab?: Function;
        selectTool?: Function;
        setMenuActive?: Function;
        closeMenu?: Function;
        getLastMode?: Function;
        refresh?: Function;
        updateTitle?: Function;
    }
    export class CollabNav3Menu extends StateLitElement {
        msize: string;
        msizeHeight: string;
        isMls2: string;
        private _menuChecked;
        private _lastMode;
        private _activeTitle;
        private _actionPage;
        private _tabSelected;
        private _historyTabs;
        private _resizeTimeout;
        private _hiddenEls;
        private msg;
        private _menu;
        private _isInternalAboutLastOpened;
        private _lastTitle;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(changed: Map<string, unknown>): void;
        render(): any;
        private _renderTools;
        private _renderTool;
        private _renderMenuList;
        private _onHamburgerChange;
        private _onTabClick;
        private _onTabFromMenu;
        private _onBackClick;
        private _onTitleClick;
        private _selectTab;
        private _initMenu;
        setMode(mode: TMode | null, page?: HTMLElement): void;
        private _updateTitle;
        private _setTabActive;
        private _tabNavigateNext;
        private _toggleErrorTab;
        private _openMenuMainItem;
        private _selectButton;
        private _closeMenu;
        private _refresh;
        private _showAbout;
        private _setMenuTitle;
        private _layoutNav3;
        private _getMenuOptions;
        private _defaultMenu;
        private _registerTooltips;
        private _onResizeWidthChange;
        private _iconTpl;
        private _faClass;
    }
}
declare module "_102041_/l2/collab-nav-3" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    type ICollabServiceState2 = 'foreground' | 'background';
    type ICollabServicePosition2 = 'left' | 'right';
    interface ICollabServiceNav3 {
        widget: string;
        state: ICollabServiceState2;
        icon: string;
        tooltip: string;
        visible: boolean;
        tags?: string[];
        isStatic: boolean;
    }
    interface ICollabServiceKeys {
        [key: number]: {
            left: ICollabServiceNav3[];
            right: ICollabServiceNav3[];
        };
    }
    export class CollabNav3 extends StateLitElement {
        dataService: string;
        level: string;
        status: string;
        msize: string;
        loading: string;
        error: string;
        loadingfeedback: string;
        get position(): ICollabServicePosition2;
        get actualServices(): ICollabServiceKeys;
        private msg;
        args?: Record<string, string>;
        getActiveInstance(position: 'left' | 'right'): any;
        layout(): void;
        instanceServicesIfNeed(services: string[]): Promise<void>;
        private _state;
        private _lastLevel;
        private _alreadyDefined;
        private _loadings;
        private _errors;
        render(): any;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(changed: Map<string, unknown>): void;
        private _init;
        private _showServiceOnlyArgs;
        private _showService;
        private _setAllVisibleFalse;
        private _hideAll;
        private _renderContainer;
        private _instanceService;
        private _instanceCollabService;
        private _createToolbarService;
        private _instanceMlsService;
        private _checkTagsAndInstanciate;
        private _instancieTagService;
        private _isStatic;
        private _isCollabService;
        private _convertFileNameToTag;
        private _onLevelChange;
        private _layout;
        private _layoutMls1;
        private _showLoading;
        private _hideLoading;
        private _changeLoadingMessage;
        private _showError;
        private _hideError;
        private _getBindService;
    }
}
declare module "_102041_/l2/collab-page" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class CollabPage extends StateLitElement {
        get msizeObj(): {
            width: number;
            height: number;
            top: number;
            left: number;
        };
        layout(): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private _onResize;
        private _setBodyHeight;
        private _updateSizeAttr;
        private _setShortCuts;
    }
}
declare module "_102041_/l2/collab-spliter-item" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class CollabSpliterItem extends StateLitElement {
        msize: string;
        layout(): void;
        render(): any;
        updated(changed: Map<string, unknown>): void;
        private _setMSizeNav3;
    }
}
declare module "_102041_/l2/collab-spliter" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class CollabSpliter extends StateLitElement {
        msize: string;
        msplit: string;
        level: string;
        msplitFullscreen: string;
        get defaultLeftPanelWidthPercent(): number;
        get defaultRightPanelWidthPercent(): number;
        get minRightPxPanel(): number;
        get minLeftPxPanel(): number;
        get msizeObj(): {
            width: number;
            height: number;
            top: number;
            left: number;
        };
        private _leftPanel?;
        private _rightPanel?;
        private _resizerSplitter?;
        private readonly _separatorWidth;
        private readonly _defaultPx;
        private _defaultPanelsWidth;
        private _actualPanelsWidth;
        private _fullScreenData;
        setFullScreen(level: number, position: 'left' | 'right' | 'default'): void;
        render(): any;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(changed: Map<string, unknown>): void;
        private _createSeparator;
        private _toogleIframePointerEvents;
        private _convertTouch;
        private _toogleDefaultWidth;
        private _updateSizePanelsOnSplitChange;
        private _setDefaultValues;
        private _getDefaultPxByPercent;
        private _updateSizePanels;
        private _loadUserPreferenceByLevel;
        private _getToolbarPxByPercent;
        private _savePreferencesByLevel;
        private _setMSplitFullScreen;
    }
}
declare module "_102041_/l2/collab-ticker" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class CollabTicker extends StateLitElement {
        text: string;
        element: string;
        render(): any;
    }
}
declare module "_102041_/l2/collab-start-l7" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import "_102041_/l2/collab-ticker";
    export class CollabStartL7 extends StateLitElement {
        language: string;
        mode: string;
        msize: string;
        private _iframeVisible;
        get baseUrl(): any;
        private get _msizeObj();
        render(): any;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(changed: Map<string, unknown>): void;
        private _loadIframe;
        private _onIframeLoaded;
        private _setEvents;
        private _loadScript;
        private _setDetailsInitialPlugin;
    }
}
declare module "_102041_/l2/collab-sticky-notification" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    type IMessageType = 'information' | 'alert' | 'error';
    interface IMessageOptions {
        autoClose?: boolean;
        timeToClose?: number;
        clearOnClose: boolean;
    }
    export class CollabStickyNotification extends StateLitElement {
        private _messages;
        private _actualIndex;
        private _actualMessage;
        private _isOpen;
        private _actualOptions;
        private msg;
        private readonly _defaultOptions;
        private get _mlsPage();
        add(message: string, typeMsg: IMessageType, options?: IMessageOptions): void;
        close(): void;
        show(): void;
        updated(): void;
        render(): any;
        private _onLeftClick;
        private _onRightClick;
        private _removeMsg;
        private _getLocalStorageMessages;
        private _saveLocalStorageMessages;
    }
}
declare module "_102041_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102027_/l2/libCompileStyle" {
    export function compileStyleUsingStorFile(shortName: string, project: number, folder: string, theme?: string): Promise<string>;
    export function compileStyleUsingMFile(modelStyle: mls.editor.IModelStyle, theme?: string): Promise<string>;
    export function compileStyleUsingSourceString(sourceLess: string, tokens: string, theme?: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeCommentLines(text: string): string;
    export function isCommentLine(line: string): boolean;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102027_/l2/processCssLit" {
    export function injectStyle(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function injectStyleAction(sourceJS: string, sourceTS: string, sourceLess: string, sourceTokens: string, theme: string, enhancementName: string): Promise<string>;
    export function injectStyleWithoutShadowRoot(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function getCssWithoutTag(css: string, tag: string): string;
}
declare module "_102041_/l2/enhancementCollab" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_102041_/l2/enhancementCollabStyle" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const onAfterChange: (models: mls.editor.IModels) => string;
    export const onAfterMarkersChange: (models: mls.editor.IModels) => string;
    export const onAfterCompile: (modelStyle: mls.editor.IModelStyle) => Promise<void>;
    export function verifyMarkersError(modelStyle: mls.editor.IModelStyle): Promise<void>;
    export function validateStyle(modelStyle: mls.editor.IModelStyle): Promise<void>;
}
declare module "_102027_/l2/pluginBaseIndex" {
    export abstract class PluginBaseIndex {
        abstract getMenus(): mls.plugin.MenuAction[];
        abstract getHooks(): mls.plugin.HookAction[];
        abstract getServices(): mls.plugin.ServiceAction[];
    }
    const _default: "disabled";
    export default _default;
}
declare module "_102041_/l2/pluginCollabCoreIndex" {
    import { PluginBaseIndex } from "_102027_/l2/pluginBaseIndex";
    export class PluginCollabCoreIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_1: PluginCollabCoreIndex;
    export default _default_1;
}
declare module "_102041_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102027_/l2/serviceBase" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export abstract class ServiceBase extends StateLitElement {
        get level(): mls.Level;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        loadingFeedBack: string;
        private _nav3Service;
        private _serviceContent;
        private _serviceItemNav;
        private _tooltipEl;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get nav3Menu(): HTMLElement;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IServiceMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string, saveState?: boolean): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string, saveState?: boolean) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
    export type ITitleClickCallBack = (title: string) => void | undefined;
    export type IMainClickCallBack = (value: string) => void | undefined;
    export type IToolsClickCallBack = (value: string) => void | undefined;
    export type ITabsClickCallBack = (index: number) => void | undefined;
    export type ITabsNavigationClickCallBack = (index: number, oldTab: HTMLElement, newTab: HTMLElement) => void | undefined;
    export type TSetMode = (mode: TMode | null, page?: HTMLElement) => void;
    export type TGetLastMode = () => TMode;
    export type TMode = 'initial' | 'page' | 'editor';
    export interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    export interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
        options: IOptions[];
    }
    export interface ITools {
        [key: string]: IToolsData;
    }
    export interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITabs {
        type: 'full' | 'onlyicon';
        effect?: 'slide' | 'none';
        mode?: 'normal' | 'compact';
        group: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    export interface IBaseToolsData {
        icon?: string;
        class?: string;
    }
    export interface IToolsData1 extends IBaseToolsData {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
    }
    export interface IToolsData2 extends IBaseToolsData {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
    }
    type IToolsData = IToolsData1 | IToolsData2;
    export interface IServiceMenu {
        enabled?: boolean;
        title: IOptions | string;
        main: IMain;
        tabs: ITabs | undefined;
        tools: ITools;
        onClickTitle?: ITitleClickCallBack;
        onClickMain?: IMainClickCallBack;
        onClickTools?: IToolsClickCallBack;
        onClickTabs?: ITabsClickCallBack;
        onClickTabsNavigation?: ITabsNavigationClickCallBack;
        setMenuActive?: (op: string) => void;
        setTabActive?: (index: number) => void;
        tabNavigate?: (index: number, oldTab: HTMLElement | undefined, newTab: HTMLElement) => void;
        tabBack?: () => void;
        toggleErrorTab?: (index: number, show: boolean) => void;
        selectTool?: (op: string) => void;
        mainDefault?: string;
        lastMain?: string;
        setMode?: TSetMode;
        refresh?: (mode?: 'full' | 'tabs' | 'tools') => void;
        closeMenu?: Function;
        getLastMode?: TGetLastMode;
        updateTitle?: Function;
    }
}
declare module "_102027_/l2/libProjectConfig" {
    export const projectConfig: IProjectConfigCache;
    export function clearLocalChanges(project: number): Promise<void>;
    export function getConfigProject(project: number, ignoreLocalChanges?: boolean): Promise<mls.l5_common.ProjectConfig | undefined>;
    export function updateConfigProject(project: number, newConfig: mls.l5_common.ProjectConfig): Promise<void>;
    export function updateConfigProjectPlugins(project: number, newPlugins: {
        [key: string]: mls.l5_common.IPlugin;
    }): Promise<void>;
    export function createConfigFile(project: number): Promise<mls.l5_common.ProjectConfig>;
    interface IProjectConfigCache {
        [key: number]: {
            versionRef: string;
            config: mls.l5_common.ProjectConfig;
        };
    }
}
declare module "_102041_/l2/servicePublish" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServicePublish102041 extends ServiceBase {
        details: IService;
        menu: IServiceMenu;
        private _msg;
        private _activeTab;
        private _loadingLangs;
        private _languages;
        private _selected;
        private _s3Config;
        private _configSaved;
        private _publishing;
        private _logs;
        private _lastVersion;
        private _copyAssets;
        private _themeObserver;
        connectedCallback(): void;
        disconnectedCallback(): void;
        onServiceClick(visible: boolean, _reinit: boolean, _el: IToolbarContent | null): void;
        private _syncDarkClass;
        render(): any;
        private _renderPublishTab;
        private _renderConfigTab;
        private _loadLanguages;
        private _toggleLang;
        private _loadS3Config;
        private _patchConfig;
        private _saveConfig;
        private _validateConfig;
        private _publish;
        private _addLog;
        /** Lists top-level datetime folders under www/ and returns the latest one. */
        private _findLastVersion;
        /** Copies the entire l3/ folder from lastVersion to newVersion for one language. */
        private _copyAssetsForLang;
        /** ListObjectsV2 with delimiter — returns CommonPrefixes (i.e. sub-folders). */
        private _s3ListPrefixes;
        /** ListObjectsV2 without delimiter — returns all object keys under prefix, paginated. */
        private _s3ListKeys;
        /** S3 server-side CopyObject — no data transfer through the browser. */
        private _s3CopyObject;
        /** S3 GET request (ListObjectsV2) — returns raw XML. */
        private _s3GetXml;
        private _updateLatestJson;
        /** S3 GET for a specific key — returns text content or null if not found. */
        private _s3GetObject;
        private _uploadToS3;
        private _hmacSHA256;
        private _getSignatureKey;
        private _sha256Hex;
        private _toHex;
    }
}
declare module "_102041_/l2/serviceStart" {
    import { ServiceBase, IService, IServiceMenu, IToolbarContent } from "_102027_/l2/serviceBase";
    export class ServiceStart extends ServiceBase {
        details: IService;
        menu: IServiceMenu;
        private _contentDiv;
        private _lastLevel;
        private _config;
        render(): any;
        onServiceClick(visible: boolean, _reinit: boolean, _el: IToolbarContent | null): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        private _showStart;
        private _showAbout;
        private _showConfig;
        private readonly _listComponentsMLS2;
        private _loadService;
        private _load;
    }
}
declare module "_102041_/l2/wcExample" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class WcExample102041 extends StateLitElement {
        name: string;
        render(): any;
    }
}
